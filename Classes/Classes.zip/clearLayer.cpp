#include "clearLayer.h"
#include "dataSingleton.h"
#include "Jdata.h"
#include "ElyonScene.h"

Jdata* pC;

Scene* clearLayer::createScene()
{
	// 'scene' is an autorelease object
	auto scene = Scene::create();

	// 'layer' is an autorelease object
	auto layer = clearLayer::create();

	// add layer as a child to scene
	scene->addChild(layer);

	// return the scene
	return scene;
}
bool clearLayer::init() {
	
	bg = Sprite::create("clearbg.png");
	bg->setAnchorPoint(Point(0, 0));
	bg->setPosition(Point(0, 0));
	this->addChild(bg);
	auto timef = CallFuncN::create(CC_CALLBACK_0(clearLayer::timef, this));
	auto rankf = CallFuncN::create(CC_CALLBACK_0(clearLayer::rankf, this));
	auto dt1 = DelayTime::create(1.0);
	auto rewardf = CallFuncN::create(CC_CALLBACK_0(clearLayer::rewardf, this));
	auto dt2 = DelayTime::create(3.0);
	auto dt3 = DelayTime::create(5.0);
	auto changescene = CallFuncN::create(CC_CALLBACK_0(clearLayer::changeScene, this));

	auto seq = Sequence::create(dt1, timef, dt1, rankf,dt2,rewardf, dt3, changescene,NULL);
	
	this->runAction(seq);

	return true;
}

void clearLayer::timef() {

	min = dataSingleton::getInstance()->minute;
	std::string mins = std::to_string(min);
	sec = dataSingleton::getInstance()->time;
	std::string secs = std::to_string(sec);
	cleartime = Label::createWithTTF(mins + " �� " + secs + " �� ", "nanumgo.ttf", 60);
	cleartime->setPosition(Point(720, 835));
	this->addChild(cleartime);

}
void clearLayer::rankf() {
	
	if (min == 0) {
		rank = Sprite::create("S.png");
		
	}
	else if (min == 1) {
		rank = Sprite::create("A.png");

	}
	else {
		rank = Sprite::create("B.png");

	}
	
	rank->setPosition(Point(560, 256));
	this->addChild(rank);
}

void clearLayer::rewardf() {
	this->removeChild(cleartime);
	this->removeChild(rank);
	bg->setTexture(Director::getInstance()->getTextureCache()->addImage("rewardbg.png"));
	int ranknum;
	if (min == 0) {
		ranknum = 4;

	}
	else if (min == 1) {
		ranknum = 3;
	}
	else if (min == 2) {
		ranknum = 2;
	}
	else
		ranknum = 1;
	
	
	for (int i = 0; i < ranknum; i++) {
		int num = (rand() % 4) + 0;
		switch (num)
		{
		case 0: {//����ġ
			auto rwexp = Sprite::create("rwexp.png");
			int expnum = (rand() % 101) + 100;
			std::string estr = std::to_string(expnum);
			auto elabel = Label::createWithTTF(estr + " EXP", "nanumgo.ttf", 24);
			int x = rwset(i);
			rwexp->setPosition(x, 580);
			elabel->setPosition(x, 480);
			this->addChild(rwexp);
			this->addChild(elabel);
			auto haveexp = pC->jjgetInt("exp", "test");
			pC->jjsetInt(haveexp + expnum, "exp", "test");
			break;
		}
		case 1: {//���
			int itemnum = (rand() % 3);
			Sprite* rwitem;
			Label* ilabel;
			if(itemnum == 0){
				rwitem = Sprite::create("rwwp.png");
				
				ilabel = Label::createWithTTF("�ʺ��� �糯��", "nanumgo.ttf", 24);
			}
			else if(itemnum == 1){
				rwitem = Sprite::create("rwsh.png");
				ilabel = Label::createWithTTF("������ ����", "nanumgo.ttf", 24);
			}
			else if(itemnum == 2){
				rwitem = Sprite::create("rwpa.png");
				ilabel = Label::createWithTTF("������ ����", "nanumgo.ttf", 24);
			}
		
			int x = rwset(i);
			rwitem->setPosition(x, 580);
			ilabel->setPosition(x , 480);
			this->addChild(rwitem);
			this->addChild(ilabel);
			
			for (int i = 0; i < 4; ) {
				//����ִ�  �迭 ã��or ������ ���̵� ã��
				auto keyid = pC->jjgetAry("keyid", "userweapon", "test", i);
				if (keyid == 999) {
					pC->jjsetAry("keyid", "userweapon", "test", itemnum, i);
					pC->jjsetAry("holding", "userweapon", "test", 1, i);
					break;
				}
				else if (keyid == itemnum) {
					auto holding = pC->jjgetAry("holding", "userweapon", "test", i);
					pC->jjsetAry("holding", "userweapon", "test", holding + 1, i);
					break;
				}
				else
					i++;
			}
			break;

		}
		case 2: {//����
			int potionnum = (rand() % 2);
			int pnum = (rand() % 3) + 1;
			std::string ponum = std::to_string(pnum);
			Sprite* rwpotion;
			Label* plabel;
			if (potionnum == 0) {
				
				rwpotion = Sprite::create("rwred.png");

				plabel = Label::createWithTTF("HP���� x "+ ponum, "nanumgo.ttf", 24);
			}
			else if (potionnum == 1) {
				rwpotion = Sprite::create("rwblue.png");
				plabel = Label::createWithTTF("MP���� x "+ ponum, "nanumgo.ttf", 24);
			}
		
			int x = rwset(i);
			rwpotion->setPosition(x, 580);
			plabel->setPosition(x, 480);
			this->addChild(rwpotion);
			this->addChild(plabel);
			for (int i = 0; i < 2; ) {
				//����ִ�  �迭 ã��or ������ ���̵� ã��
				auto keyid = pC->jjgetAry("keyid", "userpotion", "test", i);
				if (keyid == 999) {

					pC->jjsetAry("keyid", "userpotion", "test", potionnum, i);
					pC->jjsetAry("holding", "userpotion", "test", pnum, i);
					break;
				}
				else if (keyid == potionnum) {
					auto holding = pC->jjgetAry("holding", "userpotion", "test", i);
					pC->jjsetAry("holding", "userpotion", "test", holding + pnum, i);
					break;
				}
				else
					i++;
			}

			break;
		}
		case 3: {//��
			auto rwmoney = Sprite::create("rwmoney.png");
			int moneynum = (rand() % 1001) + 1000;
			std::string mstr = std::to_string(moneynum);
			auto mlabel = Label::createWithTTF(mstr + " ũ��", "nanumgo.ttf", 24);
			int x = rwset(i);
			rwmoney->setPosition(x, 580);
			mlabel->setPosition(x, 480);
			this->addChild(rwmoney);
			this->addChild(mlabel);
			auto havemoney = pC->jjgetInt("money", "test");
			pC->jjsetInt(havemoney+ moneynum, "money", "test");
			break;

		}
		default:
			break;
		}
	}
}
int clearLayer::rwset(int n){
	int x;
	switch (n)
	{
	case 0: {
		x = 360;
		break; }
	case 1: {
		x = 800;
		break; }
	case 2: {
		x = 1180;
		break;
	}
	case 3: {
		x = 1560;
		break; }
	default:
		break;
	}
	return x;
}

void clearLayer::changeScene() {

	Director::getInstance()->replaceScene(ElyonScene::createScene());
}