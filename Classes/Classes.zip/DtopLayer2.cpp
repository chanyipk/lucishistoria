#include "GameScene2.h"
#include "DtopLayer2.h"
#include "dataSingleton.h"
#include "clearLayer.h"
#include "UserLayer.h"
#include "Jdata.h"

Jdata* pD2;

int yindex2 = 1;
bool up2 = false;
bool down2 = false;
bool notfirst2 = false;
bool notfloor2 = false;

bool DtopLayer2::init() {
	if (!Layer::init()) {
		return false;
	}
	
	//�ʱ�ȭ
	MAtt = 120;
	MDef = 130;
	MHP = 3000;
	y[0] = 280;
	

	//	pD2->jjAppend("test");

	isMove = false;
	isLeftPressed = false;
	isRightPressed = false;
	isAttack = 0;
	isAPressed = false;
	jumpYN = false;
	attYN = false;
	att1 = false;
	att2 = false;
	att3 = false;
	att4 = false;
	skillYN = false;

	dataSingleton::getInstance()->bosskill = false; // ���� �׿��� �� ���� 
	dataSingleton::getInstance()->playerDead = false;

	bmon = Sprite::create("mandra1.png");
	bmon->setAnchorPoint(Point(1, 0));
	bmon->setPosition(Point(1920,100));
	bmon->setScale(0.85);
	this->addChild(bmon);

	root = Sprite::create("mandra_atk.png");
	root->setPosition(0, -500);
	this->addChild(root);
	

	setEnemy();

	// �� ��ġ
	ground1 = Sprite::create("floor1.png");
	ground1->setAnchorPoint(Point(0, 0));
	ground1->setPosition(Point(0, 0));
	this->addChild(ground1);

	//voidNode���� 
	voidNode = ParallaxNode::create();
	//	voidNode->addChild(ground1, 1, Point(1.0f, 0.0f), Point(0, 0));
	voidNode->setTag(1);
	this->addChild(voidNode, 0);




	//Ű���� Ȯ��
	uk = Sprite::create("Uk.png");
	uk->setPosition(Point(1800, 150));
	uk->setAnchorPoint(Point(0, 0));
	this->addChild(uk);
	lk = Sprite::create("Lk.png");
	lk->setPosition(Point(1800, 300));
	lk->setAnchorPoint(Point(0, 0));
	this->addChild(lk);
	rk = Sprite::create("Rk.png");
	rk->setPosition(Point(1800, 450));
	rk->setAnchorPoint(Point(0, 0));
	this->addChild(rk);

	//���ǹ�ġ
	/*red1 = Sprite::create("hppotion.png");
	red1->setTag(REDP);
	red1->setPosition(Point(0, 0));
	red1->setScale(0.8);
	red1->setVisible(false);
	this->addChild(red1);

	red2 = Sprite::create("hppotion.png");
	red2->setTag(REDP);
	red2->setPosition(Point(0, 0));
	red2->setScale(0.8);
	red2->setVisible(false);
	this->addChild(red2);

	red3 = Sprite::create("hppotion.png");
	red3->setTag(REDP);
	red3->setPosition(Point(0, 0));
	red3->setScale(0.8);
	red3->setVisible(false);
	this->addChild(red3);

	knife1 = Sprite::create("knife.png");
	knife1->setTag(KNIFE);
	knife1->setPosition(Point(0, 0));
	knife1->setScale(0.5);
	knife1->setVisible(false);
	this->addChild(knife1);

	knife2 = Sprite::create("knife.png");
	knife2->setTag(KNIFE);
	knife2->setPosition(Point(0, 0));
	knife2->setScale(0.5);
	knife2->setVisible(false);
	this->addChild(knife2);

	blue1 = Sprite::create("mppotion.png");
	blue1->setTag(BLUEP);
	blue1->setPosition(Point(0, 0));
	blue1->setScale(0.8);
	blue1->setVisible(false);
	this->addChild(blue1);

	blue2 = Sprite::create("mppotion.png");
	blue2->setTag(BLUEP);
	blue2->setPosition(Point(0, 0));
	blue2->setScale(0.8);
	blue2->setVisible(false);
	this->addChild(blue2);

	blue3 = Sprite::create("mppotion.png");
	blue3->setTag(BLUEP);
	blue3->setPosition(Point(0, 0));
	blue3->setScale(0.8);
	blue3->setVisible(false);
	this->addChild(blue3);

	//����ġ
	money1 = Sprite::create("money2.png");
	money1->setTag(MONEY);
	money1->setPosition(0, 0);
	money1->setScale(0.2);
	this->addChild(money1);

	money2 = Sprite::create("money2.png");
	money2->setTag(MONEY);
	money2->setPosition(0, 0);
	money2->setScale(0.2);
	this->addChild(money2);

	money3 = Sprite::create("money2.png");
	money3->setTag(MONEY);
	money3->setPosition(0, 0);
	money3->setScale(0.2);
	this->addChild(money3);

	money4 = Sprite::create("money2.png");
	money4->setTag(MONEY);
	money4->setPosition(0, 0);
	money4->setScale(0.2);
	this->addChild(money4);

	money5 = Sprite::create("money2.png");
	money5->setTag(MONEY);
	money5->setPosition(0, 0);
	money5->setScale(0.2);
	this->addChild(money5);
	*/
	//�÷��̾� ����

	playerSpr = Sprite::create("a1.png");
	playerSpr->setPosition(Point(200, 280));
	playerSpr->setTag(TAG_PLAYER_SPRITE);
	this->addChild(playerSpr);//���� this�� TopLayer�Դϴ�.
	playerStandAction();
							  //Ű���� ȣ��
	auto K_listner = EventListenerKeyboard::create();
	K_listner->onKeyPressed = CC_CALLBACK_2(DtopLayer2::onKeyPressed, this);
	K_listner->onKeyReleased = CC_CALLBACK_2(DtopLayer2::onKeyReleased, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(K_listner, this);

	auto UserLayer = UserLayer::create();
	this->addChild(UserLayer);

	this->scheduleUpdate();

	return true;
}

//Ű ������ �� �̺�Ʈ
void DtopLayer2::onKeyPressed(EventKeyboard::KeyCode keyCode, Event* event)
{
	auto player = (Sprite*)this->getChildByTag(TAG_PLAYER_SPRITE);
	auto pHP = dataSingleton::getInstance()->pHP;
	if (pHP>0) {
		switch (keyCode) {//Ű �ڵ尪 Ȯ��
		case EventKeyboard::KeyCode::KEY_1:
		{
			auto maxPHP = pD2->jjgetInt("maxhp", "test");
			auto PHP = pD2->jjgetInt("hp", "test");
			if (dataSingleton::getInstance()->redcount > 0 && PHP > 0 && PHP < maxPHP) {
				dataSingleton::getInstance()->redcount -= 1;

				if (PHP + 200 > maxPHP)
					dataSingleton::getInstance()->pHP = maxPHP;
				else
					dataSingleton::getInstance()->pHP = dataSingleton::getInstance()->pHP + 200;
				pD2->jjsetpArray("holding", "test", dataSingleton::getInstance()->redcount, 0);
				pD2->jjsetInt(dataSingleton::getInstance()->pHP, "hp", "test");
			}
			break;
		}
		case EventKeyboard::KeyCode::KEY_2:
		{
			auto maxPMP = pD2->jjgetInt("maxmp", "test");
			auto PMP = pD2->jjgetInt("mp", "test");
			if (dataSingleton::getInstance()->bluecount > 0 && PMP > 0 && PMP < maxPMP) {
				dataSingleton::getInstance()->bluecount -= 1;

				if (PMP + 200 > maxPMP)
					dataSingleton::getInstance()->pMP = maxPMP;
				else
					dataSingleton::getInstance()->pMP = dataSingleton::getInstance()->pMP + 200;
				pD2->jjsetpArray("holding", "test", dataSingleton::getInstance()->bluecount, 1);
				pD2->jjsetInt(dataSingleton::getInstance()->pMP, "mp", "test");
			}

			break;
		}
		case EventKeyboard::KeyCode::KEY_X://��
		{

			isUpPressed = true;

			uk->setTexture(Director::getInstance()->getTextureCache()->addImage("Ukp.png"));
			if (!jumpYN)
			{
				//startMovingBackground();
				playerSpr->stopAllActions();
				auto action = Sequence::create(JumpBy::create(1.0, Point(0, 0), 350, 1), CallFuncN::create(CC_CALLBACK_0(DtopLayer2::JumpEnd, this)), NULL);
				playerSpr->runAction(action);
				action->setTag(JUMPACT);
				jumpYN = true;
				if (isLeftPressed == false && isRightPressed == false)
				{
					auto animation = Animation::create();
					animation->setDelayPerUnit(0.1);
					animation->addSpriteFrameWithFile("j1.png");
					auto animate = Animate::create(animation);
					auto act = RepeatForever::create(animate);
					playerSpr->runAction(act);
					act->setTag(TAG_SPRITE_PLAYER_ACTION_UP);
				}
				else
				{
					auto animation = Animation::create();
					animation->setDelayPerUnit(0.1);
					animation->addSpriteFrameWithFile("rj1.png");
					auto animate = Animate::create(animation);
					auto act = RepeatForever::create(animate);
					playerSpr->runAction(act);
					act->setTag(TAG_SPRITE_PLAYER_ACTION_UP);
				}

				moveBackground(1.0);

				//break;
			}


			break;

		}
		case EventKeyboard::KeyCode::KEY_LEFT_ARROW://����
		{
			isLeftPressed = true;
			isRightPressed = false;


			lk->setTexture(Director::getInstance()->getTextureCache()->addImage("Lkp.png"));

			if (isUpPressed == false && attYN == false && skillYN == false) {
				startMovingBackground();
				playerRunAction();
			}
			else if (isUpPressed == false && (attYN == true || skillYN == true)) {

			}
			else
			{
				startMovingBackground();
				playerSpr->stopActionByTag(TAG_SPRITE_PLAYER_ACTION_UP);
				playerSpr->setTexture(Director::getInstance()->getTextureCache()->addImage("rj1.png"));
				auto animation = Animation::create();
				animation->setDelayPerUnit(0.1);
				animation->addSpriteFrameWithFile("rj1.png");

				auto animate = Animate::create(animation);
				auto act = RepeatForever::create(animate);
				playerSpr->runAction(act);
				act->setTag(TAG_SPRITE_PLAYER_ACTION_LEFT);

			}
			moveBackground(1.0);

			break;
		}

		case EventKeyboard::KeyCode::KEY_RIGHT_ARROW://������
		{

			isLeftPressed = false;
			isRightPressed = true;


			rk->setTexture(Director::getInstance()->getTextureCache()->addImage("Rkp.png"));

			if (isUpPressed == false && attYN == false && skillYN == false) {
				startMovingBackground();
				playerRunAction();
			}
			else if (isUpPressed == false && (attYN == true || skillYN == true)) {

			}
			else {
				startMovingBackground();
				playerSpr->stopActionByTag(TAG_SPRITE_PLAYER_ACTION_UP);
				playerSpr->setTexture(Director::getInstance()->getTextureCache()->addImage("rj1.png"));
				auto animation = Animation::create();
				animation->setDelayPerUnit(0.1);
				animation->addSpriteFrameWithFile("rj1.png");

				auto animate = Animate::create(animation);
				auto act = RepeatForever::create(animate);
				playerSpr->runAction(act);
				act->setTag(TAG_SPRITE_PLAYER_ACTION_RIGHT);
			}
			moveBackground(1.0);

			break;
		}
		//��ų����
		case EventKeyboard::KeyCode::KEY_A: {


			//skill���̾ �ƿ� ���� ���� ��ų�� ���� ���Ǹ� �ϰ�
			//������ �Ѱܼ� �ش� ��ȣ�� �´� ��ų�� ����ϵ��� �ϴ°� �ڵ带 ���� �� ������..?

			
			auto PMP = dataSingleton::getInstance()->pMP;
			skillid = pD2->jjgetInt("skill1", "test");
			if (skillid != 999) {
				playerSpr->stopActionByTag(TAG_SPRITE_PLAYER_ACTION_ATTACK);
				playerSpr->stopActionByTag(TAG_SPRITE_PLAYER_ACTION_UP);
				playerSpr->stopActionByTag(TAG_SPRITE_PLAYER_ACTION_STAND);
				auto skillmp = pD2->jjgetAry("skillmp", "skill", "skill", skillid);
				auto skilltime = dataSingleton::getInstance()->skillpressedA;
				if (!skillYN && PMP - skillmp > 0 && !skilltime) {
					skillhit = 0;
					isAPressed = true;
					dataSingleton::getInstance()->skillpressedA = true;
					skillYN = true;
					skillList(this, skillid);
					PMP = PMP - skillmp;
					dataSingleton::getInstance()->pMP = PMP;
					pD2->jjsetInt(PMP, "mp", "test");
				}
				else
				{
					// �̹� ȣ���Ͽ� Ÿ�̸Ӱ� ���� ���,�Ұ� �޼��� ���.
					char skillX[40];
					WideCharToMultiByte(CP_UTF8, 0, L"��ų ��� �Ұ�", -1, skillX, 1024, NULL, NULL);
					auto ban = Label::createWithTTF(skillX, "nanumgo.ttf", 30);
					ban->setPosition(Point(Director::getInstance()->
						getWinSize().width / 2, 800));
					ban->enableOutline(Color4B::WHITE);
					ban->setColor(Color3B::RED);
					this->addChild(ban);

					auto e11 = DelayTime::create(1.5);
					auto e22 = FadeOut::create(2.0);
					auto e33 = Sequence::create(e11, e22, NULL);
					ban->runAction(e33);
				}
			}

			break;

		}
		case EventKeyboard::KeyCode::KEY_Z://ZŰ
		{
			isAttack++;


			if (isUpPressed == true)
			{
				if (isRightPressed == false && isLeftPressed == false && isAttack == 1)//�⺻ ���������� ����
				{
					playerSpr->stopActionByTag(TAG_SPRITE_PLAYER_ACTION_UP);
					auto animation = Animation::create();
					animation->setDelayPerUnit(0.1);
					animation->addSpriteFrameWithFile("ja1.png");
					animation->addSpriteFrameWithFile("ja2.png");
					animation->addSpriteFrameWithFile("ja3.png");
					auto animate = Animate::create(animation);
					auto jaction1 = Sequence::create(CallFuncN::create(CC_CALLBACK_1(DtopLayer2::PattackMcrush, this)), animate, NULL);
					playerSpr->runAction(jaction1);
					animate->setTag(TAG_SPRITE_PLAYER_ACTION_ATTACK);


				}
				else {//�̵� ���� ���¿����� ���������� ���� ( �� �� �޺��� ���� ��)
					if (isAttack == 1) {

						playerSpr->stopActionByTag(TAG_SPRITE_PLAYER_ACTION_UP);
						auto animation = Animation::create();
						animation->setDelayPerUnit(0.1);
						animation->addSpriteFrameWithFile("rja1.png");
						animation->addSpriteFrameWithFile("rja2.png");
						animation->addSpriteFrameWithFile("rja4.png");
						auto animate = Animate::create(animation);
						auto rjaction1 = Sequence::create(CallFuncN::create(CC_CALLBACK_1(DtopLayer2::PattackMcrush, this)), animate, NULL);
						playerSpr->runAction(rjaction1);
						animate->setTag(TAG_SPRITE_PLAYER_ACTION_ATTACK);

					}//���� �׼��� ������ �Ʒ� �׼��� ����ǵ��� �ؾ� �ϸ� ���� �� ���� ���� �߿��� ���߿� ���� ���� �� �ֵ��� �ؾ��Ѵ�.
					 //������ �˾ƺ��� �������� 2���� �׼��� �־ �ش� �׼��� ������ ����� �� �ֵ��� �Ѵ�
					 //�ι� ���� ���� �� �� ���� ���� �и��� �� �� ���� ��� �ϳ��� act�� �ִ� �������� ������/ �ι� ������ ���� �ΰ���act�� �ִ� �������� ������

				}

			}
			else {//���� ���� ���¿����� ����
				stopMovingBackground();


				auto animation1 = Animation::create();
				animation1->setDelayPerUnit(0.3);
				animation1->addSpriteFrameWithFile("ca1.png");
				animation1->addSpriteFrameWithFile("ca2.png");
				auto animate1 = Animate::create(animation1);

				auto animation2 = Animation::create();
				animation2->setDelayPerUnit(0.3);
				animation2->addSpriteFrameWithFile("ca3.png");
				animation2->addSpriteFrameWithFile("ca4.png");
				auto animate2 = Animate::create(animation2);


				auto animation3 = Animation::create();
				animation3->setDelayPerUnit(0.3);
				animation3->addSpriteFrameWithFile("ca5.png");
				animation3->addSpriteFrameWithFile("ca6.png");
				auto animate3 = Animate::create(animation3);

				auto animation4 = Animation::create();
				animation4->setDelayPerUnit(0.3);
				animation4->addSpriteFrameWithFile("ca7.png");
				animation4->addSpriteFrameWithFile("ca8.png");
				auto animate4 = Animate::create(animation4);


				uk->setTexture(Director::getInstance()->getTextureCache()->addImage("Ukp.png"));
				attYN = true;

				if (isAttack == 1)
				{
					att1 = true;
					DelayTime *dt = DelayTime::create(0.2f);
					DelayTime *dt2 = DelayTime::create(0.05f);
					playerSpr->stopAllActions();
					action1 = Sequence::create(CallFuncN::create(CC_CALLBACK_1(DtopLayer2::PattackMcrush, this)), animate1, dt2, CallFuncN::create(CC_CALLBACK_1(DtopLayer2::AttackEnd, this)), NULL);//att2==true�� ���ôٹ߷� �Ͼ�� ������ ���������� �ϱ����ؼ� �������� �ʿ�, �� ���� ���� �ൿ�� �� �� �ֵ��� �Լ��� ������
					playerSpr->runAction(action1);



				}
				else if (isAttack == 2)
				{
					att2 = true;
					DelayTime *dt = DelayTime::create(0.2f);
					DelayTime *dt2 = DelayTime::create(0.05f);
					action2 = Sequence::create(dt, CallFuncN::create(CC_CALLBACK_1(DtopLayer2::PattackMcrush, this)), animate2, dt2, CallFuncN::create(CC_CALLBACK_1(DtopLayer2::AttackEnd, this)), NULL);
					playerSpr->runAction(action2);


				}
				else if (isAttack == 3)
				{
					att3 = true;
					DelayTime *dt = DelayTime::create(0.4f);
					DelayTime *dt2 = DelayTime::create(0.05f);
					action3 = Sequence::create(dt, CallFuncN::create(CC_CALLBACK_1(DtopLayer2::PattackMcrush, this)), animate3, dt2, CallFuncN::create(CC_CALLBACK_1(DtopLayer2::AttackEnd, this)), NULL);
					playerSpr->runAction(action3);

				}
				else if (isAttack == 4)
				{
					DelayTime *dt = DelayTime::create(0.6f);
					DelayTime *dt2 = DelayTime::create(0.05f);
					action4 = Sequence::create(dt, CallFuncN::create(CC_CALLBACK_1(DtopLayer2::PattackMcrush, this)), animate4, dt2, CallFuncN::create(CC_CALLBACK_1(DtopLayer2::AttackEnd, this)), NULL);
					playerSpr->runAction(action4);
				}

			}
			//else if{ �¿����Ű ���������� ���, �ȴ����� �������}
			break;
		}

		//������ �ݱ�
		case EventKeyboard::KeyCode::KEY_C: {


			auto play_box = playerSpr->getBoundingBox();
			Size windowSize = Director::getInstance()->getWinSize();
			char cruget[15];
			WideCharToMultiByte(CP_UTF8, 0, L" ũ�� ȹ��", -1, cruget, 1024, NULL, NULL);
			char potionget[15];
			WideCharToMultiByte(CP_UTF8, 0, L" ȹ��", -1, potionget, 1024, NULL, NULL);
			char hppotion[30];
			WideCharToMultiByte(CP_UTF8, 0, L" HP����(��)X", -1, hppotion, 1024, NULL, NULL);
			char mppotion[30];
			WideCharToMultiByte(CP_UTF8, 0, L" MP����(��)X", -1, mppotion, 1024, NULL, NULL);
			char knife[30];
			WideCharToMultiByte(CP_UTF8, 0, L" ö����X", -1, knife, 1024, NULL, NULL);

			auto havemoney = pD2->jjgetInt("money", "test");

			if (money1->isVisible())
			{
				auto item_box1 = money1->getBoundingBox();

				if (play_box.intersectsRect(item_box1)) {

					money1->setVisible(false);
					int money_r = rand() % 10 + 5;//5~14
					int money_rand = money_r * 100;//500~1400
					havemoney += money_rand;
					pD2->jjsetInt(havemoney, "money", "test");



					std::string moneyLabel = std::to_string(money_rand);
					auto label = Label::createWithTTF(moneyLabel + cruget, "nanumgo.ttf", 30);
					label->setAnchorPoint(Point(0, 0));
					label->setPosition(100, 300);
					this->addChild(label);

					auto dtm = DelayTime::create(3.0);
					auto fdm = FadeOut::create(2.0);

					auto seqm = Sequence::create(dtm, fdm, NULL);
					label->runAction(seqm);
				}
			}

			if (money2->isVisible())
			{
				auto item_box2 = money2->getBoundingBox();

				if (play_box.intersectsRect(item_box2)) {


					money2->setVisible(false);
					int money_r = rand() % 10 + 5;
					int money_rand = money_r * 100;
					havemoney += money_rand;
					pD2->jjsetInt(havemoney, "money", "test");
					std::string moneyLabel = std::to_string(money_rand);

					auto label = Label::createWithTTF(moneyLabel + cruget, "nanumgo.ttf", 30);
					label->setAnchorPoint(Point(0, 0));
					label->setPosition(100, 300);
					this->addChild(label);

					auto dtm = DelayTime::create(3.0);
					auto fdm = FadeOut::create(2.0);

					auto seqm = Sequence::create(dtm, fdm, NULL);
					label->runAction(seqm);
				}
			}

			if (money3->isVisible())
			{
				auto item_box3 = money3->getBoundingBox();

				if (play_box.intersectsRect(item_box3)) {

					money3->setVisible(false);
					int money_r = rand() % 10 + 5;
					int money_rand = money_r * 100;
					havemoney += money_rand;
					pD2->jjsetInt(havemoney, "money", "test");
					std::string moneyLabel = std::to_string(money_rand);

					auto label = Label::createWithTTF(moneyLabel + cruget, "nanumgo.ttf", 30);
					label->setAnchorPoint(Point(0, 0));
					label->setPosition(100, 300);
					this->addChild(label);

					auto dtm = DelayTime::create(3.0);
					auto fdm = FadeOut::create(2.0);

					auto seqm = Sequence::create(dtm, fdm, NULL);
					label->runAction(seqm);
				}
			}

			if (money4->isVisible())
			{
				auto item_box4 = money4->getBoundingBox();

				if (play_box.intersectsRect(item_box4)) {

					money4->setVisible(false);
					int money_r = rand() % 10 + 5;
					int money_rand = money_r * 100;
					havemoney += money_rand;
					pD2->jjsetInt(havemoney, "money", "test");
					std::string moneyLabel = std::to_string(money_rand);

					auto label = Label::createWithTTF(moneyLabel + cruget, "nanumgo.ttf", 30);
					label->setAnchorPoint(Point(0, 0));
					label->setPosition(100, 300);
					this->addChild(label);

					auto dtm = DelayTime::create(3.0);
					auto fdm = FadeOut::create(2.0);

					auto seqm = Sequence::create(dtm, fdm, NULL);
					label->runAction(seqm);
				}
			}

			if (money5->isVisible())
			{
				auto item_box5 = money5->getBoundingBox();

				if (play_box.intersectsRect(item_box5)) {

					money5->setVisible(false);
					int money_r = rand() % 10 + 5;
					int money_rand = money_r * 100;
					havemoney += money_rand;
					pD2->jjsetInt(havemoney, "money", "test");
					std::string moneyLabel = std::to_string(money_rand);

					auto label = Label::createWithTTF(moneyLabel + cruget, "nanumgo.ttf", 30);
					label->setAnchorPoint(Point(0, 0));
					label->setPosition(100, 300);
					this->addChild(label);

					auto dtm = DelayTime::create(3.0);
					auto fdm = FadeOut::create(2.0);

					auto seqm = Sequence::create(dtm, fdm, NULL);
					label->runAction(seqm);
				}
			}

			if (red1->isVisible()) {

				auto red_box1 = red1->getBoundingBox();
				int rednum = rand() % 3 + 1;
				std::string rednumStr = std::to_string(rednum);
				if (play_box.intersectsRect(red_box1)) {
					dataSingleton::getInstance()->redcount += rednum;
					pD2->jjsetpArray("holding", "test", dataSingleton::getInstance()->redcount, 0);
					red1->setVisible(false);

					auto redlabel = Label::createWithTTF(hppotion + rednumStr + potionget, "nanumgo.ttf", 30);
					redlabel->setAnchorPoint(Point(0, 0));
					redlabel->setPosition(100, 250);
					this->addChild(redlabel);

					auto dtr = DelayTime::create(3.0);
					auto fdr = FadeOut::create(2.0);
					auto seqr = Sequence::create(dtr, fdr, NULL);
					redlabel->runAction(seqr);
				}
			}

			if (red2->isVisible()) {
				auto red_box2 = red2->getBoundingBox();
				int rednum = rand() % 3 + 1;
				std::string rednumStr = std::to_string(rednum);
				if (play_box.intersectsRect(red_box2)) {
					dataSingleton::getInstance()->redcount += rednum;
					pD2->jjsetpArray("holding", "test", dataSingleton::getInstance()->redcount, 0);
					red2->setVisible(false);

					auto redlabel = Label::createWithTTF(hppotion + rednumStr + potionget, "nanumgo.ttf", 30);
					redlabel->setAnchorPoint(Point(0, 0));
					redlabel->setPosition(100, 250);
					this->addChild(redlabel);
					auto dtr = DelayTime::create(3.0);
					auto fdr = FadeOut::create(2.0);
					auto seqr = Sequence::create(dtr, fdr, NULL);
					redlabel->runAction(seqr);
				}
			}
			if (red3->isVisible()) {
				auto red_box3 = red3->getBoundingBox();
				int rednum = rand() % 3 + 1;
				std::string rednumStr = std::to_string(rednum);
				if (play_box.intersectsRect(red_box3)) {
					dataSingleton::getInstance()->redcount += rednum;
					pD2->jjsetpArray("holding", "test", dataSingleton::getInstance()->redcount, 0);
					red3->setVisible(false);

					auto redlabel = Label::createWithTTF(hppotion + rednumStr + potionget, "nanumgo.ttf", 30);
					redlabel->setAnchorPoint(Point(0, 0));
					redlabel->setPosition(100, 250);
					this->addChild(redlabel);

					auto dtr = DelayTime::create(3.0);
					auto fdr = FadeOut::create(2.0);
					auto seqr = Sequence::create(dtr, fdr, NULL);
					redlabel->runAction(seqr);
				}

			}

			

			if (blue1->isVisible()) {

				auto blue_box1 = blue1->getBoundingBox();
				int bluenum = rand() % 3 + 1;
				std::string bluenumStr = std::to_string(bluenum);
				if (play_box.intersectsRect(blue_box1)) {
					dataSingleton::getInstance()->bluecount += bluenum;
					pD2->jjsetpArray("holding", "test", dataSingleton::getInstance()->bluecount, 1);
					blue1->setVisible(false);

					auto bluelabel = Label::createWithTTF(mppotion + bluenumStr + potionget, "nanumgo.ttf", 30);
					bluelabel->setAnchorPoint(Point(0, 0));
					bluelabel->setPosition(100, 200);
					this->addChild(bluelabel);

					auto dtb = DelayTime::create(3.0);
					auto fdb = FadeOut::create(2.0);
					auto seqb = Sequence::create(dtb, fdb, NULL);
					bluelabel->runAction(seqb);
				}
			}
			if (blue2->isVisible()) {
				auto blue_box2 = blue2->getBoundingBox();
				int bluenum = rand() % 3 + 1;
				std::string bluenumStr = std::to_string(bluenum);
				if (play_box.intersectsRect(blue_box2)) {
					dataSingleton::getInstance()->bluecount += bluenum;
					pD2->jjsetpArray("holding", "test", dataSingleton::getInstance()->bluecount, 1);
					blue2->setVisible(false);

					auto bluelabel = Label::createWithTTF(mppotion + bluenumStr + potionget, "nanumgo.ttf", 30);
					bluelabel->setAnchorPoint(Point(0, 0));
					bluelabel->setPosition(100, 200);
					this->addChild(bluelabel);


					auto dtb = DelayTime::create(3.0);
					auto fdb = FadeOut::create(2.0);
					auto seqb = Sequence::create(dtb, fdb, NULL);
					bluelabel->runAction(seqb);
				}
			}
			if (blue3->isVisible()) {
				auto blue_box3 = blue3->getBoundingBox();
				int bluenum = rand() % 3 + 1;
				std::string bluenumStr = std::to_string(bluenum);
				if (play_box.intersectsRect(blue_box3)) {
					dataSingleton::getInstance()->bluecount += bluenum;
					pD2->jjsetpArray("holding", "test", dataSingleton::getInstance()->bluecount, 1);
					blue3->setVisible(false);

					auto bluelabel = Label::createWithTTF(mppotion + bluenumStr + potionget, "nanumgo.ttf", 30);
					bluelabel->setAnchorPoint(Point(0, 0));
					bluelabel->setPosition(100, 200);
					this->addChild(bluelabel);


					auto dtb = DelayTime::create(3.0);
					auto fdb = FadeOut::create(2.0);
					auto seqb = Sequence::create(dtb, fdb, NULL);
					bluelabel->runAction(seqb);
				}

			}


			break;
		}
		case EventKeyboard::KeyCode::KEY_I: {

			break;

		}
		default:
			break;
		}
	}
}

//Ű ���� �� �̺�Ʈ
void DtopLayer2::onKeyReleased(EventKeyboard::KeyCode keyCode, Event* event)
{

	switch (keyCode)
	{
	case EventKeyboard::KeyCode::KEY_X: {
		if (isUpPressed == true) {

		}

		break;
	}
	case EventKeyboard::KeyCode::KEY_A: {
		isAPressed = false;
		break;
	}
	case EventKeyboard::KeyCode::KEY_LEFT_ARROW: {
		//�ȱ� �ִϸ��̼��� ���� �ڵ��Դϴ�.
		isLeftPressed = false;
		lk->setTexture(Director::getInstance()->getTextureCache()->addImage("Lk.png"));
		auto action = (Action*)playerSpr->getActionByTag(TAG_SPRITE_PLAYER_ACTION_LEFT);
		playerSpr->getActionManager()->removeAction(action);
		if (isRightPressed == false)
			stopMovingBackground();
		break;
	}

	case EventKeyboard::KeyCode::KEY_RIGHT_ARROW: {
		//�ȱ� �ִϸ��̼��� ���� �ڵ��Դϴ�.
		isRightPressed = false;
		rk->setTexture(Director::getInstance()->getTextureCache()->addImage("Rk.png"));
		auto action = (Action*)playerSpr->getActionByTag(TAG_SPRITE_PLAYER_ACTION_RIGHT);
		playerSpr->getActionManager()->removeAction(action);
		if (isLeftPressed == false)
			stopMovingBackground();
		break;
	}
	case EventKeyboard::KeyCode::KEY_Z: {

		break;
	}
	default:
		break;
	}

	if (isRightPressed == false && isLeftPressed == false && isUpPressed == false && attYN == false && skillYN == false) { //��Ű ��Ű ��Ű �Ѵ� �ȴ����� ���� ��� �⺻ �ڼ��� ��ȯ
																														   //���� �ι� �� ���� ����µ�

		playerStandAction();
	}
}

//��� ������
void DtopLayer2::startMovingBackground()
{
	if (isLeftPressed == true && isRightPressed == true)
		return;//void�ε� ��� ������ �Ǵ��� �ǹ�...? ���� ����Ȯ���� ���ִ� �� ����.. �ϳ��� vx�� if��������..

	this->schedule(schedule_selector(DtopLayer2::moveBackground));//�����층 ����
}

//��� ����
void DtopLayer2::stopMovingBackground()
{
	this->unschedule(schedule_selector(DtopLayer2::moveBackground));
}

void DtopLayer2::moveBackground(float t)
{

	auto moveStep = 15;
	if (isLeftPressed)//�����̸� -6
	{
		moveStep = -15;
		if (attYN == false && skillYN == false)
			playerSpr->setFlippedX(true);
		//�¿� ���� �Լ�.
	}
	else//�������̸� 6
	{
		moveStep = 15;
		if (attYN == false && skillYN == false)
			playerSpr->setFlippedX(false);
		//�¿� ���� �Լ�.
	}
	auto newPos = Point(playerSpr->getPosition().x, playerSpr->getPosition().y);
	//auto newPos2 = Point(voidNode->getPosition().x, voidNode->getPosition().y);
	//float vx = voidNode->getPositionX();
	//float vy = voidNode->getPositionY();


	if (isRightPressed) {
		if (!dataSingleton::getInstance()->bosskill) {
			if (newPos.x > 1250) {
				newPos.x = 1250;
			}
			else if (newPos.x < 1250) {
				newPos.x += moveStep; //ĳ���Ͱ� �����̴� ��
			}
		}

		else{
			if (newPos.x > 1900) {
				newPos.x = 1900;
			}
			else if (newPos.x < 1900) {
				newPos.x += moveStep; //ĳ���Ͱ� �����̴� ��
			}
		}
	/*	else {//����� ������
			if (vx > -7680) {//-7680�̶��ϸ� �̹����� 4��� Ű���� ��� ������ �̹���ĭ�� �ش��� ���� ����
				newPos2.x -= moveStep; // ����� ������(�������� ���⼭ vx�� voidnode�� x�ప gx���� �ƴұ�.
			}
			else {
				newPos.x += moveStep;//�������� ĳ������ �̵�
			}
		}*/
	}
	else if (isLeftPressed) {
		if (newPos.x < 20) {
			newPos.x = 20;
		}
		else if (newPos.x >= 20 ) {
			newPos.x += moveStep; //ĳ���Ͱ� �����̴� ��
		}
/*		else {
			if (vx < 0) {
				newPos2.x -= moveStep;
			}
			else {
				newPos.x += moveStep;
			}
		}*/
	}



	float xx = playerSpr->getPositionX();
	float yy = playerSpr->getPositionY();
	dataSingleton::getInstance()->x = xx;
	dataSingleton::getInstance()->y = yy;

	

	playerSpr->setPosition(newPos);

	




}

void DtopLayer2::playerRisen()
{
	playerStandAction();
	playerSpr->setOpacity(255);

	Prisen = ParticleSystemQuad::create("riseneffect.plist");
	Prisen->setDuration(1.0);
	Prisen->setPosition(Point(playerSpr->getPositionX(), playerSpr->getPositionY() - 150));
	this->addChild(Prisen);

	dataSingleton::getInstance()->risen = false;
	gameovertrue = false;
}


//�ǽð� ����
void DtopLayer2::update(float delta)
{
	dataSingleton::getInstance()->x = playerSpr->getPositionX();
	dataSingleton::getInstance()->y= playerSpr->getPositionY();

	if (dataSingleton::getInstance()->risen == true)
	{
		playerRisen();
	}
	if (dataSingleton::getInstance()->bosskill&& !dunclear) {
		dunclear = true;
		auto enddt = DelayTime::create(8.0);
		auto callclear = CallFuncN::create(CC_CALLBACK_0(DtopLayer2::callClear, this));
		auto endse = Sequence::create(enddt, callclear, NULL);
		this->runAction(endse);

	}

	

	playertrue = playerSpr->isVisible();
	auto px = playerSpr->getPositionX();
	auto py = playerSpr->getPositionY();
	pRect = Rect(px - 600, py, 900, 300);//�÷��̾� �浹�ڽ�
	pgRect = Rect(px - 40, py, 440, 10);
	pdropRect = Rect(px - 40, py, 440, 10);

	if (skill_eff) {
		skillCrush();

	}
	
	setMAttack();


	playertrue = playerSpr->isVisible();


	//�÷��̾� ����
	PHP = dataSingleton::getInstance()->pHP;
	PEXP = dataSingleton::getInstance()->pEXP;


	if (dataSingleton::getInstance()->pHP <= 0 && !gameovertrue) {
		auto action = Sequence::create(CallFuncN::create(CC_CALLBACK_0(DtopLayer2::playerDis, this)), NULL);
		this->runAction(action);
		gameovertrue = true;
	}

	//������ �� ������ ���� y�� �˻�
	if (jumpYN) {
		up2 = false;
		down2 = false;
		auto py = playerSpr->getPositionY();
		a[0] = py;
		a[yindex2++] = playerSpr->getPositionY();
		if (a[yindex2 - 2] > a[yindex2 - 1])//�������� �ν�
		{
			down2 = true;
			auto px = playerSpr->getPositionX();
			auto py = playerSpr->getPositionY();

			pjRect = Rect(px, py, 420, 10);

			//ground3�� �ö󰡱�
			if (pjRect.intersectsRect(ground3box) || pjRect.intersectsRect(ground2box) || pjRect.intersectsRect(groundnext1box) || pjRect.intersectsRect(groundnext2box)) {
				notfirst2 = true;
				JumpEnd();
			}

		}
		else {
			down2 = false;
			up2 = true;
		}
	}
	else {
		up2 = false;
		down2 = false;
	}
	//ĳ���Ͱ� 1���� �ƴ� ������ ������ �õ��� ��
	/*	if (jumpYN&&(pD2ropRect.intersectsRect(ground3jumpbox) || pD2ropRect.intersectsRect(ground2jumpbox) || pD2ropRect.intersectsRect(groundnext1jumpbox) || pD2ropRect.intersectsRect(groundnext2jumpbox)))
	jumpcu = true;
	else
	jumpcu = false;
	*/
	//�����ϰ� �ִ� ������ ������� ����� �ʾҴ��� Ȯ��


}
/*�÷��̾� �Լ�*/
//ĳ���� ���� ��
void DtopLayer2::AttackEnd(Ref* sender)
{
	if (att1 == true) {//�����ѹ��ϰ� ����
		att1 = false;
		if (att2 == false) {
			isAttack = 0;
			AttackEndAction();
		}
	}
	else if (att2 == true) {
		att2 = false;
		if (att3 == false) {
			isAttack = 0;
			AttackEndAction();
		}
	}
	else if (att3 == true) {
		att3 = false;
		if (att4 == false) {
			isAttack = 0;
			AttackEndAction();
		}
	}
	else if (att4 == true) {
		isAttack = 0;
		att4 = false;
		AttackEndAction();
	}
	uk->setTexture(Director::getInstance()->getTextureCache()->addImage("Uk.png"));

}
void DtopLayer2::setMAttack() {
	auto time = dataSingleton::getInstance()->time;

	if (MHP>0)
	{ 
		if (time % 10 == 0 && !mSkilltrue) {
			mSkilltrue = true;
			bmon->stopAllActions();
			int num = (rand() % 3) + 0;
			switch (num) {
			case 0: {
				//���
				bmon->setTexture(Director::getInstance()->getTextureCache()->addImage("mandra_a10.png"));

				break;
			}
			case 1: {
				//�����߻�
				bmon->setTexture(Director::getInstance()->getTextureCache()->addImage("mandra_a2.png"));
				auto px = playerSpr->getPositionX();

				root->setPosition(px, -500);

				break;
			}
			case 2: {
				//������
				break;
			}
			}
			auto sdt1 = DelayTime::create(1.7);
			auto sdt2 = DelayTime::create(2.0);
			auto sf = CallFuncN::create(CC_CALLBACK_1(DtopLayer2::MskillList, this, num));
			auto se = CallFuncN::create(CC_CALLBACK_0(DtopLayer2::monSkillend, this));
			auto seq = Sequence::create(sdt1, sf, sdt2, se, NULL);
			bmon->runAction(seq);
		}
	}
}
void DtopLayer2::playerStandAction() {
	playerSpr->stopAllActions();
	auto animation = Animation::create();
	animation->setDelayPerUnit(0.2);
	animation->addSpriteFrameWithFile("a1.png");
	animation->addSpriteFrameWithFile("a2.png");
	animation->addSpriteFrameWithFile("a3.png");
	animation->addSpriteFrameWithFile("a2.png");
	auto animate = Animate::create(animation);
	auto act = RepeatForever::create(animate);
	act->setTag(TAG_SPRITE_PLAYER_ACTION_STAND);
	playerSpr->runAction(act);
}
void DtopLayer2::playerRunAction() {
	playerSpr->stopAllActions();
	auto animation = Animation::create();
	animation->setDelayPerUnit(0.1);
	animation->addSpriteFrameWithFile("r1.png");
	animation->addSpriteFrameWithFile("r2.png");
	animation->addSpriteFrameWithFile("r3.png");
	animation->addSpriteFrameWithFile("r4.png");
	animation->addSpriteFrameWithFile("r5.png");
	animation->addSpriteFrameWithFile("r6.png");
	animation->addSpriteFrameWithFile("r7.png");
	animation->addSpriteFrameWithFile("r8.png");
	auto animate = Animate::create(animation);
	auto act = RepeatForever::create(animate);
	playerSpr->runAction(act);
}
//ĳ���� ���� ���� �� �׼�
void DtopLayer2::AttackEndAction() {

	attYN = false;
	isLeftPressed = false;
	isRightPressed = false;
	playerSpr->stopAllActions();

	playerStandAction();


}
//��ų ��
void DtopLayer2::skillEnd() {
	if (!jumpYN) {
		attYN = false;
		skillYN = false;
		playerStandAction();
	}
}


//ĳ���� ���� ��
void DtopLayer2::JumpEnd()
{
	isUpPressed = false;
	isAttack = 0;
	jumpYN = false;
	skillYN = false;
	yindex2 = 1;
	if (!isLeftPressed && !isRightPressed)
		playerStandAction();
	else
		playerRunAction();
	uk->setTexture(Director::getInstance()->getTextureCache()->addImage("Uk.png"));



}
void DtopLayer2::DropEnd()
{
	isUpPressed = false;
	isAttack = 0;
	jumpYN = false;
	attYN = false;
	down2 = false;
	yindex2 = 1;
	playerStandAction();
	uk->setTexture(Director::getInstance()->getTextureCache()->addImage("Uk.png"));



}


//�÷��̾� ���� ���� �浹
void DtopLayer2::PattackMcrush(Ref* sender) {


	Rect paRect;
	mRect = Rect(1500, 100, 300, 913);
	auto mx = bmon->getPositionX();
	auto my = bmon->getPositionY();
	auto px = playerSpr->getPositionX();
	auto py = playerSpr->getPositionY();
	if (!playerSpr->isFlippedX())
		paRect = Rect(px, py, 300, 200);
	else
		paRect = Rect(px - 200, py, 300, 200);

	auto atk = pD2->jjgetInt("atk", "test");
	auto atkst = pD2->jjgetInt("atkst", "test");
	PAtt = (rand() % (atkst + 1)) + atk;//atk+���ݷ� ���������� �ִ� ������ �����Ѵ�.//atk=100,atkst=10 100~130
	if (PAtt > MDef) {
		int cri = pD2->jjgetInt("cri", "test");//10
		int cridam = pD2->jjgetInt("cridam", "test");//150
		int num = (rand() % 100) + 1;//1~100

		if (num <= cri) {
			mdamage = (PAtt*cridam) / 100 - MDef;//100*150/100-50 = 100


		}
		else
			mdamage = PAtt - MDef;//100-50 = 50;
	}
	else
		mdamage = 0;

	if (paRect.intersectsRect(mRect) && MHP > 0) {

		auto particle1 = ParticleSystemQuad::create("patteffect.plist");
		particle1->setDuration(0.2);
		particle1->setPosition(Point(mx-300, py + 45));

		this->addChild(particle1);
		if (MHP > mdamage)
		{
			MHP = MHP - mdamage;
		}
		else if (MHP <= mdamage)
		{
			MHP = 0;
		}
		damageeffect();


		//MHPS1->setPercentage(mhppercent1);
		float cu1 = MHPS->getPercentage();
		cu1 = (MHP / 3000) * 100;

		MHPS->setPercentage(cu1);
		String *str = String::createWithFormat("%.0f", MHP);
		MHPnum->setString(str->getCString());

		if (MHP <= 0) {
			
			auto fade = FadeOut::create(2.0);
			auto item = CallFuncN::create(CC_CALLBACK_0(DtopLayer2::item, this));
			auto pill = CallFuncN::create(CC_CALLBACK_0(DtopLayer2::pill, this));
			auto dis = CallFuncN::create(CC_CALLBACK_0(DtopLayer2::DeleteMon, this));
			auto giveexp = CallFuncN::create(CC_CALLBACK_0(DtopLayer2::giveexp, this));
			auto sp = Spawn::create(item, pill, dis, giveexp, NULL);
			auto s = Sequence::create(fade, sp, NULL);
			bmon->runAction(s);
		}
	}


}
										//������ ���
	


//�÷��̾� ������� ���
void DtopLayer2::playerDis() {

	playerSpr->stopAllActions();
	auto ani = Animation::create();
	ani->setDelayPerUnit(0.2);
	ani->addSpriteFrameWithFile("pD21.png");
	ani->addSpriteFrameWithFile("pD22.png");
	ani->addSpriteFrameWithFile("pD23.png");
	ani->addSpriteFrameWithFile("pD24.png");
	ani->addSpriteFrameWithFile("pD25.png");
	ani->addSpriteFrameWithFile("pD26.png");
	auto animate = Animate::create(ani);
	auto fade = FadeOut::create(2.0);
	//auto over = CallFuncN::create(CC_CALLBACK_0(UserLayer::gameover, this));
	auto dis = CallFuncN::create(CC_CALLBACK_0(DtopLayer2::playerDead, this));
	auto action = Sequence::create(animate, fade, dis, NULL);
	playerSpr->runAction(action);
}

//�÷��̾� ���� �ǵ�
void DtopLayer2::playerDead() {
	dataSingleton::getInstance()->playerDead = true;
}




/*����(+�÷��̾�) �Լ�*/

//���� �⺻ ����


void DtopLayer2::giveexp() {

	PEXP = PEXP + 500;
	dataSingleton::getInstance()->pEXP = PEXP;
	pD2->jjsetInt(PEXP, "exp", "test");
}


void DtopLayer2::itemposition() {
	float vx = voidNode->getPositionX();
	float vy = voidNode->getPositionY();

}


void DtopLayer2::skillList(Ref* sender, int n) {

	switch (n) {
	case 0: {
		auto skillanimation1 = Animation::create();
		skillanimation1->setDelayPerUnit(0.3);
		skillanimation1->addSpriteFrameWithFile("ca1.png");
		skillanimation1->addSpriteFrameWithFile("ca2.png");
		auto skillanimate1 = Animate::create(skillanimation1);
		skillanimate1->setTag(TAG_SPRITE_PLAYER_ACTION_SKILL);
		playerSpr->runAction(skillanimate1);

		auto px = playerSpr->getPositionX();
		auto py = playerSpr->getPositionY();

		DelayTime *dt3 = DelayTime::create(0.05f);


		skill_eff = Sprite::create("skill1_eff.png");
		skill_eff->setPosition(Point(px + 100, py + 30));
		this->addChild(skill_eff);
		DelayTime *dt4 = DelayTime::create(0.2f);
		MoveBy *moveaction1_1;
		if (playerSpr->isFlippedX()) {
			moveaction1_1 = MoveBy::create(0.5, Point(-400, 0));
			skill_eff->setFlippedX(true);
		}
		else {
			moveaction1_1 = MoveBy::create(0.5, Point(400, 0));
			skill_eff->setFlippedX(false);
		}
		//	auto spaweff = Spawn::create(moveaction1_1, CallFuncN::create(CC_CALLBACK_0(DtopLayer2::skillCrush, this)), NULL);
		auto seqeff = Sequence::create(moveaction1_1, CallFuncN::create(CC_CALLBACK_0(DtopLayer2::skill_effEnd, this)), NULL);
		skill_eff->runAction(seqeff);
		skill1 = Sequence::create(skillanimate1, dt3, CallFuncN::create(CC_CALLBACK_0(DtopLayer2::skillEnd, this)), NULL);
		playerSpr->runAction(skill1);


	}
	}
}

void DtopLayer2::skill_effEnd() {
	skill_eff->setVisible(false);

}
void DtopLayer2::setEnemy() {
	
	mhps_back = Sprite::create("bmhpbar.png");
	mhps_back->setAnchorPoint(Point(0.5, 0.5));
	mhps_back->setPosition(Point(960, 950));
	mhps_back->setScale(0.8);
	this->addChild(mhps_back);

	auto mhps1 = Sprite::create("bmhps.png");
	MHPS = ProgressTimer::create(mhps1);
	MHPS->setType(ProgressTimer::Type::BAR);
	MHPS->setAnchorPoint(Point(0.5, 0.5));
	MHPS->setPosition(Point(960, 950));
	MHPS->setMidpoint(Point(0, 0));
	MHPS->setBarChangeRate(Point(1, 0));
	MHPS->setPercentage(100);
	MHPS->setScale(0.8);
	this->addChild(MHPS);

	MHPnum = Label::createWithTTF("3000", "nanumgo.ttf", 30);
	MHPnum->setPosition(Point(872, 62));
	MHPS->addChild(MHPnum);

	Mname = Label::createWithTTF("Lv.5 ������", "nanumgo.ttf", 30);
	Mname->setPosition(Point(872,150));
	MHPS->addChild(Mname);


	auto animation1 = Animation::create();
	animation1->setDelayPerUnit(0.5);
	animation1->addSpriteFrameWithFile("mandra1.png");
	animation1->addSpriteFrameWithFile("mandra2.png");
	animation1->addSpriteFrameWithFile("mandra3.png");
	auto animate1 = Animate::create(animation1);
	auto act1 = RepeatForever::create(animate1);
	act1->setTag(MonsterStandMotion);
	bmon->runAction(act1);
}

void DtopLayer2::damageeffect() {
	auto mx = bmon->getPositionX();
	auto my = bmon->getPositionY();

	std::string mdamageStr;
	if (mdamage == 0)
		mdamageStr = "MISS";
	else
		mdamageStr = std::to_string(mdamage);

	auto mdamagelabel = Label::createWithTTF(mdamageStr, "drfont.ttf", 50);
	mdamagelabel->setPosition(Point(mx -300, my + 700));
	mdamagelabel->enableOutline(Color4B::BLACK, 1);

	if (mdamage == PAtt - MDef && mdamage != 0)//�Ϲݰ���
		mdamagelabel->setColor(Color3B(255, 255, 255));
	else if (mdamage>PAtt - MDef && MDef< PAtt) {
		mdamagelabel->setColor(Color3B(170, 18, 18));//�˻�����(ũ��Ƽ��)
	}
	else if (mdamage == 0)//miss
		mdamagelabel->setColor(Color3B(255, 187, 0));//�����

	this->addChild(mdamagelabel);

	auto fade = FadeOut::create(2.0f);
	auto move = MoveBy::create(2, Point(0, 150));
	auto spaw = Spawn::create(fade, move, NULL);
	mdamagelabel->runAction(spaw);
}
void DtopLayer2::DeleteMon() {
	bmon->stopAllActions();
	dataSingleton::getInstance()->bosskill = true;
	this->removeChild(bmon);
	this->removeChild(MHPS);
	this->removeChild(mhps_back);
}
void DtopLayer2::item()
{}
void DtopLayer2::pill()
{}

void DtopLayer2::skillCrush() {
	if (skill_eff->isVisible()) {
		
		auto skillx = skill_eff->getPositionX();
		auto skilly = skill_eff->getPositionY();
		auto mx = bmon->getPositionX();
		
		auto atk = pD2->jjgetInt("atk", "test");
		//��ų�� ���Ϳ��� ��
		switch (skillid) {
		case 0: {


			auto skillRect = Rect(skillx , skilly, 1000, 162);
			auto skillmod = skillhit % 5;

			skillhit++;
			auto skillefftrue = skill_eff->isVisible();
			auto maxhit = 6;//json���� �����;��Ѵ�. ���� ���ϱ� ��ų�� ���� �Լ��� �ƿ� ���� ����
							//Ű���̵�� �ش� ��ų�� ���õ� �������� �Լ����� �������� ���·� �����ؾ� �ҵ��ϴ�.
			if (skillRect.intersectsRect(mRect) && skillefftrue && skillhit <= maxhit * 5 && skillmod == 0 && MHP>0) {

				auto particle = ParticleSystemQuad::create("skillmonatk.plist");
				particle->setDuration(0.05);
				particle->setPosition(Point(mx - 300, 200));
				this->addChild(particle);
				auto skilleff = pD2->jjgetAry("effect", "skill", "skill", skillid);

				mdamage = (atk*skilleff) / 100 - MDef;
				if (MHP > mdamage)
				{
					MHP = MHP - mdamage;
				}
				else if (MHP <= mdamage)
				{
					MHP = 0;
				}
				damageeffect();


				//MHPS1->setPercentage(mhppercent1);
				float cu1 = MHPS->getPercentage();
				cu1 = (MHP / 3000) * 100;

				MHPS->setPercentage(cu1);
				String *str = String::createWithFormat("%.0f", MHP);
				MHPnum->setString(str->getCString());

				if (MHP <= 0) {

					auto fade = FadeOut::create(2.0);
					auto item = CallFuncN::create(CC_CALLBACK_0(DtopLayer2::item, this));
					auto pill = CallFuncN::create(CC_CALLBACK_0(DtopLayer2::pill, this));
					auto dis = CallFuncN::create(CC_CALLBACK_0(DtopLayer2::DeleteMon, this));
					auto giveexp = CallFuncN::create(CC_CALLBACK_0(DtopLayer2::giveexp, this));
					auto sp = Spawn::create(item, pill, dis, giveexp, NULL);
					auto s = Sequence::create(fade, sp, NULL);
					bmon->runAction(s);
				}
			}
		}
		default: break;
		}

	}
}
void DtopLayer2::MskillList(Ref* sender, int n) {
	int num = n;
	switch (num) {
	case 0: {
		
		//���
		auto sanimation0 = Animation::create();
		sanimation0->setDelayPerUnit(0.2);
		sanimation0->addSpriteFrameWithFile("mandra_a11.png");
		sanimation0->addSpriteFrameWithFile("mandra_a12.png");
		auto sanimate0 = Animate::create(sanimation0);
		bmon->runAction(sanimate0);
		break;
	}
	case 1: {
		//�����߻�
		auto moveactionup= MoveBy::create(0.05, Point(0, 800));
		auto moveactiondown = MoveBy::create(0.05, Point(0, -800));
		auto movedt = DelayTime::create(1.0);
		auto moveseq = Sequence::create(moveactionup, movedt, moveactiondown, NULL);
		root->runAction(moveseq);
		
		break;
	}
	case 2: {
		//������
		break;
	}
	}
}
void DtopLayer2::monSkillend() {
	bmon->stopAllActions();
	mSkilltrue = false;
	auto animation1 = Animation::create();
	animation1->setDelayPerUnit(0.5);
	animation1->addSpriteFrameWithFile("mandra1.png");
	animation1->addSpriteFrameWithFile("mandra2.png");
	animation1->addSpriteFrameWithFile("mandra3.png");
	auto animate1 = Animate::create(animation1);
	auto act1 = RepeatForever::create(animate1);
	act1->setTag(MonsterStandMotion);
	bmon->runAction(act1);
}

void DtopLayer2::callClear() {
	auto clearLayer =clearLayer::create();
	this->addChild(clearLayer);

}