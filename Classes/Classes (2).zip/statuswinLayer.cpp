#include "statuswinLayer.h"
#include "Jdata.h"
#include "dataSingleton.h"
Jdata* pS;

Scene* statuswinLayer::createScene()
{
	// 'scene' is an autorelease object
	auto scene = Scene::create();

	// 'layer' is an autorelease object
	auto layer = statuswinLayer::create();

	// add layer as a child to scene
	scene->addChild(layer);

	// return the scene
	return scene;
}

bool statuswinLayer::init() {
	if (!Layer::init()) {
		return false;
	}
	dataSingleton::getInstance()->winopen = true;

	auto background = Sprite::create("background.png");
	background->setAnchorPoint(Point(0, 0));
	background->setPosition(Point(0, 0));
	this->addChild(background);

	auto status_win = Sprite::create("status.png");
	status_win->setAnchorPoint(Point(0.5, 0.5));
	status_win->setPosition(Point(Director::getInstance()->
		getWinSize().width / 2, Director::getInstance()->
		getWinSize().height / 2));
	status_win->setTag(STATUSW);
	this->addChild(status_win);

	auto exit = MenuItemImage::create("exit.png", "exit_push.png", CC_CALLBACK_1(statuswinLayer::closebut, this));
	auto exit_b = Menu::create(exit, NULL);
	exit_b->setTag(EXIT);
	exit_b->setPosition(Point(1685, 962));
	this->addChild(exit_b);

	int classnum = pS->jjgetInt("class", "test");

	std::string name = pS->jjgetString("name", "test");

	int level = pS->jjgetInt("level", "test");
	std::string levelstr = std::to_string(level);

	int maxhp = pS->jjgetInt("maxhp", "test");
	std::string maxhpstr = std::to_string(maxhp);

	int hp = pS->jjgetInt("hp", "test");
	std::string hpstr = std::to_string(hp);

	int maxmp = pS->jjgetInt("maxmp", "test");
	std::string maxmpstr = std::to_string(maxmp);

	int mp = pS->jjgetInt("mp", "test");
	std::string mpstr = std::to_string(mp);

	int maxexp = pS->jjgetInt("maxexp", "test");
	std::string maxexpstr = std::to_string(maxexp);

	int exp = pS->jjgetInt("exp", "test");
	std::string expstr = std::to_string(exp);

	int money = pS->jjgetInt("money", "test");
	std::string moneystr = std::to_string(money);

	int atk = pS->jjgetInt("atk", "test");
	std::string atkstr = std::to_string(atk);

	int atkst = pS->jjgetInt("atkst", "test");
	std::string atkststr = std::to_string(atkst);

	int def = pS->jjgetInt("def", "test");
	std::string defstr = std::to_string(def);

	int defst = pS->jjgetInt("defst", "test");
	std::string defststr = std::to_string(defst);

	int cri = pS->jjgetInt("cri", "test");
	std::string cristr = std::to_string(cri);

	int cridam = pS->jjgetInt("cridam", "test");
	std::string cridamstr = std::to_string(cridam);

	switch (classnum)
	{
	case 1: {
		auto pro = Sprite::create("man.png");
		pro->setScale(0.50);
		pro->setAnchorPoint(Point(0.5, 0));
		pro->setPosition(Point(630, 93));
		status_win->addChild(pro);
		auto classttf = Label::createWithTTF("KNIGHT", "nanumgo.ttf", 30);
		classttf->setAnchorPoint(Point(0.5, 0.5));
		classttf->setPosition(Point(620, 835));
		status_win->addChild(classttf);

		break;
	}
	default:
		break;
	}


	auto levelnamettf = Label::createWithTTF("Lv.  " + levelstr + " " + name, "nanumgo.ttf", 40);
	levelnamettf->setAnchorPoint(Point(0.5, 0.5));
	levelnamettf->setPosition(Point(620, 880));
	status_win->addChild(levelnamettf);

	auto hpmaxhpttf = Label::createWithTTF("HP  " + hpstr + " / " + maxhpstr, "nanumgo.ttf", 35);
	hpmaxhpttf->setAnchorPoint(Point(0, 0));
	hpmaxhpttf->setPosition(Point(1050, 800));
	status_win->addChild(hpmaxhpttf);

	auto mpmaxmpttf = Label::createWithTTF("MP  " + mpstr + " / " + maxmpstr, "nanumgo.ttf", 35);
	mpmaxmpttf->setAnchorPoint(Point(0, 0));
	mpmaxmpttf->setPosition(Point(1360, 800));
	status_win->addChild(mpmaxmpttf);

	auto expmaxexpttf = Label::createWithTTF("EXP  " + expstr + " / " + maxexpstr, "nanumgo.ttf", 35);
	expmaxexpttf->setAnchorPoint(Point(0, 0));
	expmaxexpttf->setPosition(Point(1050, 720));
	status_win->addChild(expmaxexpttf);


	auto atkatkstttf = Label::createWithTTF("ATK  " + atkstr + " (+" + atkststr + ")", "nanumgo.ttf", 35);
	atkatkstttf->setAnchorPoint(Point(0, 0));
	atkatkstttf->setPosition(Point(1050, 640));
	status_win->addChild(atkatkstttf);

	auto defdefstttf = Label::createWithTTF("DEF  " + defstr + " (+" + defststr + ")", "nanumgo.ttf", 35);
	defdefstttf->setAnchorPoint(Point(0, 0));
	defdefstttf->setPosition(Point(1360, 640));
	status_win->addChild(defdefstttf);

	auto crittf = Label::createWithTTF("CRITICAL  " + cristr +  " (%)", "nanumgo.ttf", 35);//+0�� ��� ����� �����ϵ���
	crittf->setAnchorPoint(Point(0, 0));
	crittf->setPosition(Point(1050, 560));
	status_win->addChild(crittf);

	auto cridamttf = Label::createWithTTF("CRITICAL DAMAGE  " + cridamstr +  " (%)", "nanumgo.ttf", 35);//+0�� ��� ����� �����ϵ���
	cridamttf->setAnchorPoint(Point(0, 0));
	cridamttf->setPosition(Point(1050, 480));
	status_win->addChild(cridamttf);


	auto moneyttf = Label::createWithTTF(moneystr, "nanumgo.ttf", 35);
	moneyttf->setAnchorPoint(Point(1, 0));
	moneyttf->setPosition(Point(1600, 110));
	status_win->addChild(moneyttf);
}
void statuswinLayer::closebut(Ref *sender) {
	dataSingleton::getInstance()->winopen = false;
	this->removeAllChildren();
}


