#include "StoreLayer.h"
#include "BuyLayer.h"
#include "ElyonScene.h"
#include "PotionLayer.h"
#include "WeaponLayer.h"

bool ispLayer = false;
bool iswLayer = false;

Scene* StoreLayer::createScene()
{
	// 'scene' is an autorelease object
	auto scene = Scene::create();

	// 'layer' is an autorelease object
	auto layer = StoreLayer::create();

	// add layer as a child to scene
	scene->addChild(layer);

	// return the scene
	return scene;
}

bool StoreLayer::init() {

	if (!Layer::init()) {
		return false;
	}
	auto background = Sprite::create("background.png");
	background->setAnchorPoint(Point(0, 0));
	background->setPosition(Point(0, 0));
	this->addChild(background);

	auto store1 = Sprite::create("store1.png");
	store1->setAnchorPoint(Point(0, 0.5));
	store1->setPosition(Point(Director::getInstance()->
		getWinSize().width / 4, Director::getInstance()->
		getWinSize().height / 9 * 5 - 30));
	this->addChild(store1);

	auto exit = Sprite::create("exit.png");
	exit->setAnchorPoint(Point(0, 0));
	exit->setPosition(Point(1600, 1000));
	exit->setScale(0.7);
	this->addChild(exit);

	iswLayer = true;
	auto wp = WeaponLayer::create();
	this->addChild(wp, 100, W_LAYER);

	//���� ������ ���ù�ư   //����
	auto weapon = MenuItemImage::create("weapon.png", "weapon.png", CC_CALLBACK_1(StoreLayer::itemSelect, this));
	auto weaponb = Menu::create(weapon, NULL);
	weaponb->setAnchorPoint(Point(0, 0));
	weaponb->setPosition(Point(250, 830));
	weapon->setTag(WEAPON);
	this->addChild(weaponb);

	//��
	auto shild = MenuItemImage::create("shild.png", "shild.png", CC_CALLBACK_1(StoreLayer::itemSelect, this));
	shild->setTag(SHILD);
	auto shildb = Menu::create(shild, NULL);
	shildb->setAnchorPoint(Point(0, 0));
	shildb->setPosition(Point(250, 670));
	this->addChild(shildb);


	//��������
	auto acc = MenuItemImage::create("acc.png", "acc.png", CC_CALLBACK_1(StoreLayer::itemSelect, this));
	acc->setTag(ACC);
	auto accb = Menu::create(acc, NULL);
	accb->setAnchorPoint(Point(0, 0));
	accb->setPosition(Point(250, 510));
	this->addChild(accb);


	//����
	auto potion = MenuItemImage::create("potion.png", "potion.png", CC_CALLBACK_1(StoreLayer::itemSelect, this));
	potion->setTag(POTION);
	auto potionb = Menu::create(potion, NULL);
	potionb->setAnchorPoint(Point(0, 0));
	potionb->setPosition(Point(250, 350));
	this->addChild(potionb);

	EventDispatcher * dispatcher2 = Director::getInstance()->getEventDispatcher();

	//���� ���� ��� �̹����� ������ ��� �߻��Ǵ� �̺�Ʈ�� �����ʸ� �����մϴ�.
	//������ �Լ��� �̸��� onPositionTouchBegan�Դϴ�.
	auto closeListener = EventListenerTouchOneByOne::create();
	closeListener->setSwallowTouches(true);
	closeListener->onTouchBegan = CC_CALLBACK_2(StoreLayer::onCloseTouchBegan, this);
	dispatcher2->addEventListenerWithSceneGraphPriority(closeListener, exit);

	return true;
}


bool StoreLayer::onCloseTouchBegan(Touch * touch, Event * event) {

	//��ġ�� ��ü�� Ÿ�ٿ� �����մϴ�.
	auto target = (Sprite *)event->getCurrentTarget();
	Point pos = target->convertToNodeSpace(touch->getLocation());
	Rect rect = Rect(0, 0, target->getContentSize().width, target->getContentSize().height);

	if (rect.containsPoint(pos)) {
		this->removeFromParentAndCleanup(target);
		return true;
	}
	else
	{
		return false;
	}
}

void StoreLayer::itemSelect(cocos2d::Ref* sender) {

	auto but = (MenuItem*)sender;


	if (but->getTag() == WEAPON) {
		if (ispLayer == true) {
			this->removeChildByTag(P_LAYER, true);
			ispLayer = false;
		}
		if (iswLayer == false) {
			iswLayer = true;
			auto wp = WeaponLayer::create();
			this->addChild(wp, 100, W_LAYER);
		}
	}
	else if (but->getTag() == POTION) {
		if (iswLayer == true) {
			this->removeChildByTag(W_LAYER, true);
			iswLayer = false;
		}
		auto player = PotionLayer::create();
		this->addChild(player, 200, P_LAYER);
		ispLayer = true;
	}
}

