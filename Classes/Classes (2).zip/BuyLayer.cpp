#include "StoreLayer.h"
#include "ElyonScene.h"
#include "BuyLayer.h"
#include "Jdata.h"
#include "dataSingleton.h"
#include "StoreLayer.h"
#include "PotionLayer.h"

int hnum;
int arrayorder;
Jdata* buypL;
int result;
int userCash;
int itemPrice;

Scene* BuyLayer::createScene()
{
	// 'scene' is an autorelease object
	auto scene = Scene::create();

	// 'layer' is an autorelease object
	auto layer = BuyLayer::create();

	// add layer as a child to scene
	scene->addChild(layer);

	// return the scene
	return scene;
}

bool BuyLayer::init() {

	if (!Layer::init()) {
		return false;
	}

	buypL = dynamic_cast<Jdata*>(getParent());


	result = 0;
	userCash = dataSingleton::getInstance()->userMoney;
	itemPrice = dataSingleton::getInstance()->price;

	if (userCash >= itemPrice && itemPrice != 0) {
		result = userCash - itemPrice;
		dataSingleton::getInstance()->userMoney = result;
		

		hnum = dataSingleton::getInstance()->holdingnum;
		arrayorder = dataSingleton::getInstance()->cashtag;

		/* ���Ǹ� ���Ű����� ���� �ڵ�
		buypL->jjsetInt(result, "money", "test");
		hnum = hnum+ buypL->jjgetpArray("holding", "test", arrayorder);
		buypL->jjsetpArray("holding","test",hnum, arrayorder);
		*/

		int keyid = dataSingleton::getInstance()->itemkeyid;
		buypL->jjsetInt(result, "money", "test");

		if (arrayorder == 0) {//���⸦ �����ߴٴ� ��
			if (keyid == 0) {
				for (int i = 0; i < 4;) {
					auto id1 = buypL->jjgetAry("keyid", "userweapon", "test", i);
					if (id1 == keyid) {
						hnum = hnum + buypL->jjgetAry("holding", "userweapon", "test", i);
						buypL->jjsetAry("holding", "userweapon", "test", hnum, i);
						break;
					}
					else if (id1 == 999) {
						buypL->jjsetAry("keyid", "userweapon", "test", id1, i);
						hnum = hnum + buypL->jjgetAry("holding", "userweapon", "test", i);
						buypL->jjsetAry("holding", "userweapon", "test", hnum, i);
						break;
					}
					else i++;
				}
			}
			else if (keyid == 1) {
				for (int i = 0; i < 4;) {
					auto id1 = buypL->jjgetAry("keyid", "userweapon", "test", i);
					if (id1 == keyid) {
						hnum = hnum + buypL->jjgetAry("holding", "userweapon", "test", i);
						buypL->jjsetAry("holding", "userweapon", "test", hnum, i);
						break;
					}
					else if (id1 == 999) {
						buypL->jjsetAry("keyid", "userweapon", "test", id1, i);
						hnum = hnum + buypL->jjgetAry("holding", "userweapon", "test", i);
						buypL->jjsetAry("holding", "userweapon", "test", hnum, i);
						break;
					}
					else i++;
				}
			}
		}
		else if (arrayorder == 1) {//������ �����ߴٴ� ��
			if (keyid == 0) {
				for (int i = 0; i < 2;) {
					auto id1 = buypL->jjgetAry("keyid", "userpotion", "test", i);
					if (id1 == keyid) {
						hnum = hnum + buypL->jjgetAry("holding", "userpotion", "test", i);
						buypL->jjsetAry("holding", "userpotion", "test", hnum, i);
						break;
					}
					else if (id1 == 999) {
						buypL->jjsetAry("keyid", "userpotion", "test", id1, i);
						hnum = hnum + buypL->jjgetAry("holding", "userpotion", "test", i);
						buypL->jjsetAry("holding", "userpotion", "test", hnum, i);
						break;
					}
					else i++;
				}
			}
			else if (keyid == 1) {
				for (int i = 0; i < 2;) {
					auto id1 = buypL->jjgetAry("keyid", "userpotion", "test", i);
					if (id1 == keyid) {
						hnum = hnum + buypL->jjgetAry("holding", "userpotion", "test", i);
						buypL->jjsetAry("holding", "userpotion", "test", hnum, i);
						break;
					}
					else if (id1 == 999) {
						buypL->jjsetAry("keyid", "userpotion", "test", id1, i);
						hnum = hnum + buypL->jjgetAry("holding", "userpotion", "test", i);
						buypL->jjsetAry("holding", "userpotion", "test", hnum, i);
						break;
					}
					else i++;
				}
			}
		}

		auto done = MenuItemImage::create("market.png", "market.png");
		auto check = MenuItemImage::create("close.png", "close.png", CC_CALLBACK_1(BuyLayer::ok, this));
		auto checkb = Menu::create(done, check, NULL);
		checkb->setAnchorPoint(Point(0.5,0.5));
		checkb->alignItemsVertically();
		checkb->setPosition(Point(Director::getInstance()->
			getWinSize().width / 2, Director::getInstance()->
			getWinSize().height / 2));
		this->addChild(checkb);
	}
	else {
		auto notice = MenuItemImage::create("notice.png", "notice.png");
		auto cancel = MenuItemImage::create("close.png", "close.png", CC_CALLBACK_1(BuyLayer::exit, this));
		auto cancelb = Menu::create(notice, cancel, NULL);
		cancelb->alignItemsVertically();
		cancelb->setAnchorPoint(Point(0.5,0.5));
	
		cancelb->setPosition(Point(Director::getInstance()->
			getWinSize().width / 2, Director::getInstance()->
			getWinSize().height / 2));
		this->addChild(cancelb);
	}

	return true;
}

void BuyLayer::exit(cocos2d::Ref* sender) {
	//auto exitbut = (MenuItem*)sender;
	//this->removeFromParentAndCleanup(exitbut);
	Director::getInstance()->popScene();
}


void BuyLayer::ok(cocos2d::Ref* sender) {
	//PotionLayer* potion = dynamic_cast<PotionLayer*>(getParent());

	Director::getInstance()->popScene();
	//auto okbut = (MenuItem*)sender;
	//this->removeFromParentAndCleanup(okbut);
}
