#include "GameScene.h"
#include "DtopLayer.h"
#include "dataSingleton.h"
#include "userLayer.h"
#include "ElyonScene.h"
#include "Jdata.h"

Jdata* pG;

Scene* GameScene::createScene()
{
	// 'scene' is an autorelease object
	auto scene = Scene::create();

	// 'layer' is an autorelease object
	auto layer = GameScene::create();

	// add layer as a child to scene
	scene->addChild(layer);

	// return the scene
	return scene;
}
bool GameScene::init() {
	if (!Layer::init()) {
		return false;
	}
	dataSingleton::getInstance()->elyonScene = false;
	initBG();

	auto DtopLayer = DtopLayer::create();
	this->addChild(DtopLayer);

/*	auto MonsterLayer= MonsterLayer::create();
	this->addChild(MonsterLayer);
*/
	

	auto exit_but = MenuItemImage::create("cirbut.png", "cirbut_push.png", CC_CALLBACK_1(GameScene::endclicked, this));
	auto exit = Menu::create(exit_but, NULL);
	exit->alignItemsVertically();
	exit->setAnchorPoint(Point(0.5, 0.5));
	exit->setPosition(Point(1200, 150));
	exit->setScale(0.35);
	this->addChild(exit);


	auto UserLayer = UserLayer::create();
	this->addChild(UserLayer);

	return true;

	

}
void GameScene::endclicked(Ref* sender) {

	auto background = Sprite::create("background.png");
	background->setAnchorPoint(Point(0, 0));
	background->setPosition(Point(0, 0));
	background->setTag(BACK);
	this->addChild(background);


	auto msg = Sprite::create("message2.png");
	msg->setScale(0.7);
	msg->setPosition(Point(Director::getInstance()->
		getWinSize().width / 2, Director::getInstance()->
		getWinSize().height / 2 + 100));
	msg->setTag(MSG);
	this->addChild(msg);

	auto cancel = MenuItemImage::create("cancel.png", "cancel_push.png", CC_CALLBACK_1(GameScene::okayclicked, this));
	cancel->setTag(CA);
	auto cc = Menu::create(cancel, NULL);
	cc->alignItemsVertically();
	cc->setAnchorPoint(Point(0, 0));
	cc->setTag(CA1);
	cc->setPosition(Point(Director::getInstance()->
		getWinSize().width / 2 + 225, Director::getInstance()->
		getWinSize().height / 2 - 100));
	this->addChild(cc);

	auto okay = MenuItemImage::create("check.png", "check_push.png", CC_CALLBACK_1(GameScene::okayclicked, this));
	okay->setTag(OK);
	auto oa = Menu::create(okay, NULL);
	oa->alignItemsVertically();
	oa->setAnchorPoint(Point(0, 0));
	oa->setTag(OK1);
	oa->setPosition(Point(Director::getInstance()->
		getWinSize().width / 2 - 225, Director::getInstance()->
		getWinSize().height / 2 - 100));
	this->addChild(oa);


}

void GameScene::okayclicked(Ref* sender) {
	auto q = (MenuItem*)sender;
	switch (q->getTag()) {

	case OK: {


		auto background = (Sprite*)this->getChildByTag(BACK);
		this->removeChild(background);


		auto msg = (Sprite*)this->getChildByTag(MSG);
		this->removeChild(msg);

		auto oa = (Menu*)this->getChildByTag(OK1);
		this->removeChild(oa);

		auto cc = (Menu*)this->getChildByTag(CA1);
		this->removeChild(cc);

		
		auto maxhp = pG->jjgetInt("maxhp", "test");
		auto maxmp = pG->jjgetInt("maxmp", "test");
		auto penlhp = maxhp*0.1;
		auto penlmp = maxmp*0.1;
		pG->jjsetInt(penlhp, "hp", "test");
		pG->jjsetInt(penlmp, "mp", "test");
		Director::getInstance()->replaceScene(ElyonScene::createScene());

		break;
	}
	case CA: {

		auto background = (Sprite*)this->getChildByTag(BACK);
		this->removeChild(background);

	

		auto msg = (Sprite*)this->getChildByTag(MSG);
		this->removeChild(msg);

		auto oa = (Menu*)this->getChildByTag(OK1);
		this->removeChild(oa);

		auto cc = (Menu*)this->getChildByTag(CA1);
		this->removeChild(cc);

		break;
	}
	default: {
		break;
	}
	}

}
void GameScene::initBG() {
	auto bgimg = Sprite::create("b1.png", Rect(0, 0, 1920, 1080));
	bgimg->setAnchorPoint(Point::ZERO);
	bgimg->setPosition(Point::ZERO);
	this->addChild(bgimg);
}