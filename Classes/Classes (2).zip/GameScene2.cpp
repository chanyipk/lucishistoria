#include "GameScene2.h"
#include "DtopLayer2.h"
#include "dataSingleton.h"
#include "userLayer.h"
#include "ElyonScene.h"
#include "Jdata.h"
#include "SimpleAudioEngine.h"

Jdata* pG2;

Scene* GameScene2::createScene()
{
	// 'scene' is an autorelease object
	auto scene = Scene::create();

	// 'layer' is an autorelease object
	auto layer = GameScene2::create();

	// add layer as a child to scene
	scene->addChild(layer);

	// return the scene
	return scene;
}
bool GameScene2::init() {
	if (!Layer::init()) {
		return false;
	}
	dataSingleton::getInstance()->elyonScene = false;

	initBG();
	change = 0;
	dataSingleton::getInstance()->time = 0;
	dataSingleton::getInstance()->minute = 0;

	CocosDenshion::SimpleAudioEngine::getInstance()->playBackgroundMusic("Heated Battle.mp3", true);
	//CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("siren.mp3");


	auto DtopLayer2 = DtopLayer2::create();
	this->addChild(DtopLayer2);

	/*	auto MonsterLayer= MonsterLayer::create();
	this->addChild(MonsterLayer);
	*/
	auto particle = ParticleSystemQuad::create("rainpart.plist");
	particle->setDuration(-1);
	particle->setAnchorPoint(Point(0, 0));
	particle->setPosition(Point(0, 0));
	this->addChild(particle);

	auto exit_but = MenuItemImage::create("cirbut.png", "cirbut_push.png", CC_CALLBACK_1(GameScene2::endclicked, this));
	auto exit = Menu::create(exit_but, NULL);
	exit->alignItemsVertically();
	exit->setAnchorPoint(Point(0.5, 0.5));
	exit->setPosition(Point(1200, 150));
	exit->setScale(0.35);
	this->addChild(exit);


	addLabelTimer(this, 0, Vec2(1060, 900));



	return true;



}
void GameScene2::endclicked(Ref* sender) {

	auto background = Sprite::create("background.png");
	background->setAnchorPoint(Point(0, 0));
	background->setPosition(Point(0, 0));
	background->setTag(BACK);
	this->addChild(background);


	auto msg = Sprite::create("message2.png");
	msg->setScale(0.7);
	msg->setPosition(Point(Director::getInstance()->
		getWinSize().width / 2, Director::getInstance()->
		getWinSize().height / 2 + 100));
	msg->setTag(MSG);
	this->addChild(msg);

	auto cancel = MenuItemImage::create("cancel.png", "cancel_push.png", CC_CALLBACK_1(GameScene2::okayclicked, this));
	cancel->setTag(CA);
	auto cc = Menu::create(cancel, NULL);
	cc->alignItemsVertically();
	cc->setAnchorPoint(Point(0, 0));
	cc->setTag(CA1);
	cc->setPosition(Point(Director::getInstance()->
		getWinSize().width / 2 + 225, Director::getInstance()->
		getWinSize().height / 2 - 100));
	this->addChild(cc);

	auto okay = MenuItemImage::create("check.png", "check_push.png", CC_CALLBACK_1(GameScene2::okayclicked, this));
	okay->setTag(OK);
	auto oa = Menu::create(okay, NULL);
	oa->alignItemsVertically();
	oa->setAnchorPoint(Point(0, 0));
	oa->setTag(OK1);
	oa->setPosition(Point(Director::getInstance()->
		getWinSize().width / 2 - 225, Director::getInstance()->
		getWinSize().height / 2 - 100));
	this->addChild(oa);


}

void GameScene2::okayclicked(Ref* sender) {
	auto q = (MenuItem*)sender;
	switch (q->getTag()) {

	case OK: {


		auto background = (Sprite*)this->getChildByTag(BACK);
		this->removeChild(background);


		auto msg = (Sprite*)this->getChildByTag(MSG);
		this->removeChild(msg);

		auto oa = (Menu*)this->getChildByTag(OK1);
		this->removeChild(oa);

		auto cc = (Menu*)this->getChildByTag(CA1);
		this->removeChild(cc);


		auto maxhp = pG2->jjgetInt("maxhp", "test");
		auto maxmp = pG2->jjgetInt("maxmp", "test");
		auto penlhp = maxhp*0.1;
		auto penlmp = maxmp*0.1;
		pG2->jjsetInt(penlhp, "hp", "test");
		pG2->jjsetInt(penlmp, "mp", "test");
		Director::getInstance()->replaceScene(ElyonScene::createScene());

		break;
	}
	case CA: {

		auto background = (Sprite*)this->getChildByTag(BACK);
		this->removeChild(background);



		auto msg = (Sprite*)this->getChildByTag(MSG);
		this->removeChild(msg);

		auto oa = (Menu*)this->getChildByTag(OK1);
		this->removeChild(oa);

		auto cc = (Menu*)this->getChildByTag(CA1);
		this->removeChild(cc);

		break;
	}
	default: {
		break;
	}
	}

}
void GameScene2::initBG() {
	auto bgimg = Sprite::create("b2.png", Rect(0, 0, 1920, 1080));
	bgimg->setAnchorPoint(Point::ZERO);
	bgimg->setPosition(Point::ZERO);
	this->addChild(bgimg);

	auto tint1 = TintTo::create(0.5, 255, 0, 0);
	auto tint2 = TintTo::create(0.5, Color3B::BLACK);
	auto tint3 = TintTo::create(0.5, 255, 255, 255);
	auto seque = Sequence::create(tint1, tint2, NULL);
	auto rep = Repeat::create(seque, 3);
	auto end = Sequence::create(rep, tint3, NULL);
	bgimg->runAction(end);
}



void GameScene2::addLabelTimer(Node* pParent, int nTime, const cocos2d::Vec2& pos)
{
	auto pLabelTime = Label::create(StringUtils::toString(nTime), "Arial", 40);
	pLabelTime->setUserData((int*)nTime);
	pParent->addChild(pLabelTime);
	pLabelTime->setPosition(pos);
	pLabelTime->setVisible(false);

	minute1 = Label::create("0:", "Arial", 40);
	minute1->setPosition(Point(960, 900));
	minute1->setTag(MIN);
	minute1->setVisible(false);
	this->addChild(minute1);//����

	auto scheduleAction = CallFuncN::create(CC_CALLBACK_0(GameScene2::updateLabel, this, pLabelTime));
	auto repeatF = RepeatForever::create(Sequence::create(scheduleAction, DelayTime::create(1.0f), nullptr));
	pLabelTime->runAction(repeatF);

}

void GameScene2::updateLabel(Label* pLabel)
{
	if (pLabel)
	{
		int userTime = (int)(pLabel->getUserData());
		userTime += 1;
		pLabel->setString(StringUtils::toString(userTime));
		dataSingleton::getInstance()->time = userTime;

		if (dataSingleton::getInstance()->bosskill == true)
		{
			pLabel->stopAllActions();
		}

		if (userTime == 60) {
		
			userTime = 0;
			dataSingleton::getInstance()->time = userTime;
			pLabel->setString(StringUtils::toString(userTime));
			change++;
			dataSingleton::getInstance()->minute = change;
			std::string min = std::to_string(change);
			/*if (change == 1) {
				minute1->setString("1:");
				dataSingleton::getInstance()->minute = 1;
			}
			else if (change == 2) {

				minute1->setString("2:");
				dataSingleton::getInstance()->minute = 1;
			}
			else if (change == 3) {
				minute1->setString("3:");
				pLabel->stopAllActions();
				this->removeChild(pLabel);
			}*/
			minute1->setString(min + ":");
		
		}

	
		pLabel->setUserData((int*)userTime);
	}

}
