#ifndef __MAIN_SCENE_H__
#define __MAIN_SCENE_H__

#include "cocos2d.h"
#define CLOSE_SPRITE 0
#define STANDARD_SPRITE_1 1
#define STANDARD_SPRITE_2 2
#define CIRBUT_1 3
#define CIRBUT_2 4
#define PLAYER_0 0
#define ENTERBTN 5

USING_NS_CC; //using namespace cocos2d

class MainScene : public Layer
{
public:

	static Scene* createScene();
	virtual bool init();
	CREATE_FUNC(MainScene);
	void changeScene(Ref *sender);
	void ButtonCallBack1(Ref *sender);
	void ButtonCallBack2(Ref *sender);
	void ButtonCallBack3(Ref *sender);
	void initBG();
	void makeWin();
	void plyrListshow();
	void playerSelect(Ref* sender);
	void gotomapScene(Ref *sender);
};

#endif

