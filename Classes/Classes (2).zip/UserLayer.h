#pragma once
#ifndef __USER_LAYER_H__
#define __USER_LAYER_H__
#define RISEN 0
#define SHIFT 1
#define REDP 10
#define statb 101
#define itemb 102
#define skillb 103
#define questb 104
#define backb 105
#define exitb 106
#define STATUSW 1000
#define BACK 109
#define MAGIC1 110
#define MAGIC2 111
#define RISE_WIN 112
#define BUT_1 113
#define BUT_2 114
#define OK 115
#define CA 116
#define MSG 117
#define OK1 118
#define CA1 119
#define EXIT 8000

#include "cocos2d.h"

USING_NS_CC;

class UserLayer : public Layer
{
public:

	virtual bool init();

	//ĳ���� �������� ��������Ʈ

	Sprite* mpbar;
	ProgressTimer* PEXPbar;
	ProgressTimer* PHPbar;
	ProgressTimer* PMPbar;
	LabelTTF* hpnumsTTF;
	LabelTTF* mpnumsTTF;
	LabelTTF* expnumsTTF;
	LabelTTF* levelnumsTTF;
	//Sprite* red;
	Menu* red;
	Menu* blue;
	//ĳ���� �������� ��ġ
	int level;
	float PHP;//ĳ���� ü��
	float PMP;
	float PEXP;
	float maxPEXP;
	 
	bool skilltime;
	bool gameovertrue;
	bool playerDead;
	void gameover();
	void update(float delta);
	void redpotion();
	void levelupeffect();
	void risenpush(Ref* sender);
	void shiftpush(Ref* sender);
	void button(Ref* sender);
	void risenokay(Ref* sender);
	void onSprTouchBegan(Ref* sender);
	void onSprTouchBegan2(Ref* sender);
	void updateLabel(Label* pLabel);
	void addLabelTimer(Node* pParent, int nTime, const cocos2d::Vec2& pos);
	void shiftokay(Ref* sender);
	Sprite* skillbox1;

	CREATE_FUNC(UserLayer);
};


#endif // __TOP_LAYER_H__#pragma once
