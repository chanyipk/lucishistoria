#include "Jdata.h"
#include <cstdio>
#include "../../cocos2d/external/json/rapidjson.h"
#include "../../cocos2d/external/json/document.h"
#include "../../cocos2d/external/json/filestream.h"
#include "../../cocos2d/external/json/stringbuffer.h"
#include "../../cocos2d/external/json/writer.h"
#include "../../cocos2d/external/json/filewritestream.h"
#include "../../cocos2d/external/json/filereadstream.h"

using rapidjson::FileReadStream;
using rapidjson::FileWriteStream;

USING_NS_CC;

using namespace rapidjson;

Document doc;
char readBuffer[65536];
//StringBuffer readBuffer;
StringBuffer writeBuffer;

Scene* Jdata::createScene()
{
	// 'scene' is an autorelease object
	auto scene = Scene::create();

	// 'layer' is an autorelease object
	auto layer = Jdata::create();

	// add layer as a child to scene
	scene->addChild(layer);

	// return the scene
	return scene;
}

bool Jdata::init()
{

	if (!Layer::init())
	{
		return false;
	}

	//�⺻ �� �ʱ�ȭ
	readBuffer[0] = '\0';
	writeBuffer.Flush();
	writeBuffer.Clear();


	return true;
}

bool Jdata::fileRead(std::string fName) {//get�� set�Լ� ����� ���� �⺻ ������ ���� �Լ�

										 //���̸� ���� ���-> std::string path = "C:\\json\\";
										 //���õ� ����� os�� �°� ���������� path�� �����ݴϴ�.
										 //���� ���� �������->win32�� ��ο� �°� 
										 // D:\aaa\bbb\ccc\ddd\abc.txt --> D:/aaa/bbb/ccc/ddd/abc.txt
										 //static inline std::string convertPathFormatToUnixStyle(const std::string& path)
										 //std::string path = FileUtils::sharedFileUtils()->getWritablePath();
	std::string path = "C:\\json\\";

	path.append(fName);//path�� �����̸� �߰�
	path.append(".json");//���� ���� �߰�
						 //log("path: %s", path.c_str());
	bool fexist = FileUtils::sharedFileUtils()->isFileExist(path);
	if (fexist == true) {

		FILE* fp = fopen(path.c_str(), "rb+");

		if (!fp) {
			log("file read failed");
			return false;
		}
		else {
			readBuffer[0] = '\0';
			writeBuffer.Flush();
			writeBuffer.Clear();

			FileReadStream inputStrm(fp, readBuffer, sizeof(readBuffer));
			fclose(fp);

			if (doc.Parse(readBuffer).HasParseError() == true) {
				return true;
			}
			else {
				return true;
			}
		}
		return true;
	}
	else {

		return false;
	}
}

std::string Jdata::jjgetString(const char* keystr, std::string fName) {

	bool readflag = fileRead(fName);
	if (!readflag) {
		return "";
	}
	else
	{
		return doc[keystr].GetString();
	}
}

void Jdata::jjsetString(std::string setstr, const char* keystr, std::string fName) {

	bool readflag = fileRead(fName);
	if (!readflag) {
	}
	else
	{
		const char* cstr = setstr.c_str();
		doc[keystr].SetString(StringRef(cstr));
		writetoFile(fName);
	}
}

int Jdata::jjgetInt(const char* keystr, std::string fName) {

	bool readflag = fileRead(fName);
	if (!readflag) {
		return 2323;
	}
	else
	{
		return doc[keystr].GetInt();
	}
}

void Jdata::jjsetInt(int setint, const char* keystr, std::string fName) {

	bool readflag = fileRead(fName);
	if (!readflag) {
	}
	else
	{
		doc[keystr].SetInt(setint);
		writetoFile(fName);
	}
}

bool Jdata::jjgetBool(const char* keystr, std::string fName) {

	bool readflag = fileRead(fName);
	if (!readflag) {
		return "";
	}
	else
	{
		return doc[keystr].GetBool();
	}
}

void Jdata::jjsetBool(bool setbool, const char* keystr, std::string fName) {

	bool readflag = fileRead(fName);
	if (!readflag) {
		//log("jjsetBool failed");
	}
	else
	{
		doc[keystr].SetBool(setbool);
		writetoFile(fName);
	}
}

//�����.json�� ����Ʈ ���� �� bool�� �����ϴ� �Լ�
void Jdata::jjsetArray(const char* keystr, std::string fName, bool tf, int order) {
	rapidjson::Document testData;

	std::string fpath = "C:\\json\\";
	//std::string fpath = FileUtils::sharedFileUtils()->getWritablePath();

	fpath.append(fName);
	fpath.append(".json");

	Data data = FileUtils::getInstance()->getDataFromFile(fpath);
	ssize_t size = data.getSize();

	char* jsonBuffer = new char[size + 1];
	memcpy(jsonBuffer, data.getBytes(), size);
	jsonBuffer[size] = '\0';
	data.clear();

	if (testData.ParseInsitu<0>(jsonBuffer).HasParseError() == false)
	{
		rapidjson::Value& userquest = testData["userquest"];

		rapidjson::Value& b = userquest[order][keystr];//�̷� ������ ���۷����� Value&�� �����ؼ� ����մϴ�.

		b.SetBool(tf);
	}
	else
	{
		CCASSERT(false, "ModifyArray type Parse json failed");
	}
	FILE* fpointer = fopen(fpath.c_str(), "wb+");

	StringBuffer b;
	Writer<StringBuffer> writer(b);
	testData.Accept(writer);

	std::string fData = b.GetString();
	const char* schar = fData.c_str();

	fputs(fData.c_str(), fpointer);
	fclose(fpointer);

}

//�����.json�� ����Ʈ ���� �� bool�� ��ȯ�ϴ� �Լ�
bool Jdata::jjgetArray(const char* keystr, std::string fName, int order) {
	rapidjson::Document testData;

	std::string fpath = "C:\\json\\";
	//std::string fpath = FileUtils::sharedFileUtils()->getWritablePath();

	fpath.append(fName);
	fpath.append(".json");

	Data data = FileUtils::getInstance()->getDataFromFile(fpath);
	ssize_t size = data.getSize();

	char* jsonBuffer = new char[size + 1];
	memcpy(jsonBuffer, data.getBytes(), size);
	jsonBuffer[size] = '\0';
	data.clear();

	if (testData.ParseInsitu<0>(jsonBuffer).HasParseError() == false)
	{
		rapidjson::Value& userquest = testData["userquest"];

		rapidjson::Value& b = userquest[order][keystr];//�̷� ������ ���۷����� Value&�� �����ؼ� ����մϴ�.

		return b.GetBool();
	}
	else
	{
		CCASSERT(false, "ModifyArray type Parse json failed");
	}
}

//�����.json�� ����Ʈ ���� �� int�� �����ϴ� �Լ�
void Jdata::jjsetQint(const char* keystr, std::string fName, int setint, int order) {
	rapidjson::Document testData;

	std::string fpath = "C:\\json\\";
	//std::string fpath = FileUtils::sharedFileUtils()->getWritablePath();

	fpath.append(fName);
	fpath.append(".json");

	Data data = FileUtils::getInstance()->getDataFromFile(fpath);
	ssize_t size = data.getSize();

	char* jsonBuffer = new char[size + 1];
	memcpy(jsonBuffer, data.getBytes(), size);
	jsonBuffer[size] = '\0';
	data.clear();

	if (testData.ParseInsitu<0>(jsonBuffer).HasParseError() == false)
	{
		rapidjson::Value& userquest = testData["userquest"];

		rapidjson::Value& b = userquest[order][keystr];//�̷� ������ ���۷����� Value&�� �����ؼ� ����մϴ�.

		b.SetInt(setint);
	}
	else
	{
		CCASSERT(false, "ModifyArray type Parse json failed");
	}
	FILE* fpointer = fopen(fpath.c_str(), "wb+");

	StringBuffer b;
	Writer<StringBuffer> writer(b);
	testData.Accept(writer);

	std::string fData = b.GetString();
	const char* schar = fData.c_str();

	fputs(fData.c_str(), fpointer);
	fclose(fpointer);

}

//�����.json�� ����Ʈ ���� �� int�� ��ȯ�ϴ� �Լ�
int Jdata::jjgetQint(const char* keystr, std::string fName, int order) {
	rapidjson::Document testData;

	std::string fpath = "C:\\json\\";
	//std::string fpath = FileUtils::sharedFileUtils()->getWritablePath();

	fpath.append(fName);
	fpath.append(".json");

	Data data = FileUtils::getInstance()->getDataFromFile(fpath);
	ssize_t size = data.getSize();

	char* jsonBuffer = new char[size + 1];
	memcpy(jsonBuffer, data.getBytes(), size);
	jsonBuffer[size] = '\0';
	data.clear();

	if (testData.ParseInsitu<0>(jsonBuffer).HasParseError() == false)
	{
		rapidjson::Value& userquest = testData["userquest"];

		rapidjson::Value& b = userquest[order][keystr];//�̷� ������ ���۷����� Value&�� �����ؼ� ����մϴ�.

		return b.GetInt();
	}
	else
	{
		CCASSERT(false, "ModifyArray type Parse json failed");
	}
}


//�����.json�� ���� ���� �� int�� ��ȯ�ϴ� �Լ�
int Jdata::jjgetpArray(const char* keystr, std::string fName, int order) {
	rapidjson::Document testData;

	std::string fpath = "C:\\json\\";
	//std::string fpath = FileUtils::sharedFileUtils()->getWritablePath();

	fpath.append(fName);
	fpath.append(".json");

	Data data = FileUtils::getInstance()->getDataFromFile(fpath);
	ssize_t size = data.getSize();

	char* jsonBuffer = new char[size + 1];
	memcpy(jsonBuffer, data.getBytes(), size);
	jsonBuffer[size] = '\0';
	data.clear();

	if (testData.ParseInsitu<0>(jsonBuffer).HasParseError() == false)
	{
		//log("In ParseInsitu");
		rapidjson::Value& userpotion = testData["userpotion"];

		rapidjson::Value& p = userpotion[order][keystr];//�̷� ������ ���۷����� Value&�� �����ؼ� ����մϴ�.

		return p.GetInt();
	}
	else
	{
		CCASSERT(false, "ModifyArray type Parse json failed");
	}
	FILE* fpointer = fopen(fpath.c_str(), "wb+");

	StringBuffer b;
	Writer<StringBuffer> writer(b);
	testData.Accept(writer);

	std::string fData = b.GetString();
	const char* schar = fData.c_str();

	//log("data: %s", fData.c_str());
	//log("data: %s", schar);

	fputs(fData.c_str(), fpointer);
	fclose(fpointer);

}

//�����.json�� ���� ���� �� int�� �����ϴ� �Լ�
void Jdata::jjsetpArray(const char* keystr, std::string fName, int setint, int order) {
	//log("In Modify Potion Array function");
	rapidjson::Document testData;

	std::string fpath = "C:\\json\\";
	//std::string fpath = FileUtils::sharedFileUtils()->getWritablePath();

	fpath.append(fName);
	fpath.append(".json");

	Data data = FileUtils::getInstance()->getDataFromFile(fpath);
	ssize_t size = data.getSize();
	//log("path: %s", fpath.c_str());

	char* jsonBuffer = new char[size + 1];
	memcpy(jsonBuffer, data.getBytes(), size);
	jsonBuffer[size] = '\0';
	data.clear();

	if (testData.ParseInsitu<0>(jsonBuffer).HasParseError() == false)
	{
		//log("In ParseInsitu");
		rapidjson::Value& userpotion = testData["userpotion"];

		rapidjson::Value& p = userpotion[order][keystr];//�̷� ������ ���۷����� Value&�� �����ؼ� ����մϴ�.

		p.SetInt(setint);
	}
	else
	{
		CCASSERT(false, "ModifyArray type Parse json failed");
	}
	FILE* fpointer = fopen(fpath.c_str(), "wb+");

	StringBuffer b;
	Writer<StringBuffer> writer(b);
	testData.Accept(writer);

	std::string fData = b.GetString();
	const char* schar = fData.c_str();

	//log("data: %s", fData.c_str());
	//log("data: %s", schar);

	fputs(fData.c_str(), fpointer);
	fclose(fpointer);

}

//(�����/����/����).json�� ��� �迭�̵� int���� ������ �� �ִ� �Լ�
//�Ű������� (keystr-������ value��), (keyary-������ value�� ���� �迭�� �̸�)�� ����մϴ�.
//fName�� potion�̳� weapon���� �����ϸ� �ش� JSON������ ��� ������ �����մϴ�.
void Jdata::jjsetAry(const char* keystr, const char * keyary, std::string fName, int setint, int order) {
	rapidjson::Document testData;

	std::string fpath = "C:\\json\\";
	//std::string fpath = FileUtils::sharedFileUtils()->getWritablePath();

	fpath.append(fName);
	fpath.append(".json");

	Data data = FileUtils::getInstance()->getDataFromFile(fpath);
	ssize_t size = data.getSize();

	char* jsonBuffer = new char[size + 1];
	memcpy(jsonBuffer, data.getBytes(), size);
	jsonBuffer[size] = '\0';
	data.clear();

	if (testData.ParseInsitu<0>(jsonBuffer).HasParseError() == false)
	{
		rapidjson::Value& userquest = testData[keyary];

		rapidjson::Value& b = userquest[order][keystr];//�̷� ������ ���۷����� Value&�� �����ؼ� ����մϴ�.

		b.SetInt(setint);
	}
	else
	{
		CCASSERT(false, "ModifyArray type Parse json failed");
	}
	FILE* fpointer = fopen(fpath.c_str(), "wb+");

	StringBuffer b;
	Writer<StringBuffer> writer(b);
	testData.Accept(writer);

	std::string fData = b.GetString();
	const char* schar = fData.c_str();

	fputs(fData.c_str(), fpointer);
	fclose(fpointer);

}
std::string Jdata::jjgetSAry(const char* keystr, const char * keyary, std::string fName, int order) {

	rapidjson::Document testData;

	std::string fpath = "C:\\json\\";
	//std::string fpath = FileUtils::sharedFileUtils()->getWritablePath();

	fpath.append(fName);
	fpath.append(".json");

	Data data = FileUtils::getInstance()->getDataFromFile(fpath);
	ssize_t size = data.getSize();

	char* jsonBuffer = new char[size + 1];
	memcpy(jsonBuffer, data.getBytes(), size);
	jsonBuffer[size] = '\0';
	data.clear();

	if (testData.ParseInsitu<0>(jsonBuffer).HasParseError() == false)
	{
		//log("In ParseInsitu");
		rapidjson::Value& userpotion = testData[keyary];

		rapidjson::Value& p = userpotion[order][keystr];//�̷� ������ ���۷����� Value&�� �����ؼ� ����մϴ�.

		return p.GetString();
	}
	else
	{
		CCASSERT(false, "ModifyArray type Parse json failed");
	}
	FILE* fpointer = fopen(fpath.c_str(), "wb+");

	StringBuffer b;
	Writer<StringBuffer> writer(b);
	testData.Accept(writer);

	std::string fData = b.GetString();
	const char* schar = fData.c_str();

	//log("data: %s", fData.c_str());
	//log("data: %s", schar);

	fputs(fData.c_str(), fpointer);
	fclose(fpointer);
}

//(�����/����/����).json�� ��� �迭�̵� int���� ��ȯ�� �� �ִ� �Լ�
//�Ű������� (keystr-������ value��), (keyary-������ value�� ���� �迭�� �̸�)�� ����մϴ�.
//fName�� potion�̳� weapon���� �����ϸ� �ش� JSON������ ��� ������ ��ȯ�մϴ�.
int Jdata::jjgetAry(const char* keystr, const char * keyary, std::string fName, int order) {
	rapidjson::Document testData;

	std::string fpath = "C:\\json\\";
	//std::string fpath = FileUtils::sharedFileUtils()->getWritablePath();

	fpath.append(fName);
	fpath.append(".json");

	Data data = FileUtils::getInstance()->getDataFromFile(fpath);
	ssize_t size = data.getSize();

	char* jsonBuffer = new char[size + 1];
	memcpy(jsonBuffer, data.getBytes(), size);
	jsonBuffer[size] = '\0';
	data.clear();

	if (testData.ParseInsitu<0>(jsonBuffer).HasParseError() == false)
	{
		//log("In ParseInsitu");
		rapidjson::Value& userpotion = testData[keyary];

		rapidjson::Value& p = userpotion[order][keystr];//�̷� ������ ���۷����� Value&�� �����ؼ� ����մϴ�.

		return p.GetInt();
	}
	else
	{
		CCASSERT(false, "ModifyArray type Parse json failed");
	}
	FILE* fpointer = fopen(fpath.c_str(), "wb+");

	StringBuffer b;
	Writer<StringBuffer> writer(b);
	testData.Accept(writer);

	std::string fData = b.GetString();
	const char* schar = fData.c_str();

	//log("data: %s", fData.c_str());
	//log("data: %s", schar);

	fputs(fData.c_str(), fpointer);
	fclose(fpointer);
}

void Jdata::jjAppend(std::string fName) {//fName.json�� �����ϴ� �Լ�

										 //std::string path = FileUtils::sharedFileUtils()->getWritablePath();
	std::string path = "C:\\json\\";
	path.append(fName);
	path.append(".json");
	//log("path: %s", path.c_str());
	bool fexist = FileUtils::sharedFileUtils()->isFileExist(path);
	if (fexist == true) {}
	else {
		FILE* fp = fopen(path.c_str(), "wb+");//fopen ������ �������� ���� ��� �ڵ� �����ϵ��� wb+ ������ �־����ϴ�.

		if (!fp) {
			//log("cannot create file: %s", path);
		}
		else {
			//log("JSON Append Test");

			Document initdoc;
			initdoc.SetObject();
			rapidjson::Document::AllocatorType& allocator = initdoc.GetAllocator();

			rapidjson::Value chaName;
			char buff[10];

			//string ���� �׽�Ʈ�� �ڵ�
			//SizeType len2 = strlen(buff);

			int len = sprintf(buff, "%s", fName.c_str());
			chaName.SetString(buff, len, allocator);
			memset(buff, 0, sizeof(buff));

			initdoc.AddMember("name", chaName, allocator);

			//������ default string Value �ڵ�
			//initdoc.AddMember("name", " ", allocator);

			//������ default int Value �ڵ�
			//rapidjson::Value val(0);
			rapidjson::Value val;
			initdoc.AddMember("name", "test", allocator);
			val.SetInt(1);
			initdoc.AddMember("class", val, allocator);
			val.SetInt(130);
			initdoc.AddMember("atk", val, allocator);
			val.SetInt(10);
			initdoc.AddMember("atkst", val, allocator);
			val.SetInt(10);
			initdoc.AddMember("cri", val, allocator);
			val.SetInt(150);
			initdoc.AddMember("cridam", val, allocator);
			val.SetInt(130);
			initdoc.AddMember("def", val, allocator);
			val.SetInt(10);
			initdoc.AddMember("defst", val, allocator);
			val.SetInt(0);
			initdoc.AddMember("exp", val, allocator);
			val.SetInt(1300);
			initdoc.AddMember("hp", val, allocator);
			val.SetInt(1);
			initdoc.AddMember("level", val, allocator);
			val.SetInt(1000);
			initdoc.AddMember("maxexp", val, allocator);
			val.SetInt(1300);
			initdoc.AddMember("maxhp", val, allocator);
			val.SetInt(1000);
			initdoc.AddMember("maxmp", val, allocator);
			val.SetInt(0);
			initdoc.AddMember("money", val, allocator);
			val.SetInt(1000);
			initdoc.AddMember("mp", val, allocator);
			val.SetInt(999);
			initdoc.AddMember("skill1", val, allocator);
			val.SetInt(999);
			initdoc.AddMember("skill2", val, allocator);
			val.SetInt(999);
			initdoc.AddMember("skill3", val, allocator);
			val.SetInt(999);
			initdoc.AddMember("skill4", val, allocator);
			val.SetInt(999);
			initdoc.AddMember("wweapon", val, allocator);
			val.SetInt(999);
			initdoc.AddMember("wshirts", val, allocator);
			val.SetInt(999);
			initdoc.AddMember("itemants", val, allocator);
			val.SetInt(999);
			initdoc.AddMember("wac1", val, allocator);
			val.SetInt(999);
			initdoc.AddMember("wac2", val, allocator);


			rapidjson::Value userquest(kArrayType);//������� quest ����� �迭�� ����

			rapidjson::Value uquest0;
			uquest0.SetObject();
			uquest0.AddMember("read", false, allocator);//quest read ����
			uquest0.AddMember("done", false, allocator);//quest ���࿩��
			uquest0.AddMember("qpngname", "ep1-1.png", allocator);//ep1-1 quest ���� �̹���
			uquest0.AddMember("questname", "quest0npc1", allocator);//quest �̸� Ȥ�� �±׷� ��밡��
			uquest0.AddMember("condition", 1, allocator);//����Ʈ ����
			uquest0.AddMember("nowing", 0, allocator);//����Ʈ ���� ���������Ȳ
			uquest0.AddMember("questname", "quest0npc1", allocator);//quest �̸� Ȥ�� �±׷� ���
			uquest0.AddMember("rwrdcash", 10, allocator);//rewardcash �����
			uquest0.AddMember("rwrdExp", 10, allocator);//rewardExp ����ġ����
			uquest0.AddMember("rwrdhp", 10, allocator);//rewardhp hp����(����)

			userquest.PushBack(uquest0, allocator);

			rapidjson::Value uquest1;
			uquest1.SetObject();
			uquest1.AddMember("read", false, allocator);//quest read ����
			uquest1.AddMember("done", false, allocator);//quest ���࿩��
			uquest1.AddMember("qpngname", "ep1-2.png", allocator);//ep1-1 quest ���� �̹���
			uquest1.AddMember("questname", "quest2npc2", allocator);//quest �̸� Ȥ�� �±׷� ��밡��
			uquest0.AddMember("condition", 1, allocator);//����Ʈ ����
			uquest0.AddMember("nowing", 0, allocator);//����Ʈ ���� ���������Ȳ
			uquest1.AddMember("rwrdcash", 10, allocator);//rewardcash �����
			uquest1.AddMember("rwrdExp", 10, allocator);//rewardExp ����ġ����
			uquest1.AddMember("rwrdhp", 10, allocator);//rewardhp hp����(����)

			userquest.PushBack(uquest1, allocator);

			rapidjson::Value uquest2;
			uquest2.SetObject();
			uquest2.AddMember("read", false, allocator);//quest read ����
			uquest2.AddMember("done", false, allocator);//quest ���࿩��
			uquest2.AddMember("qpngname", "ep1-3.png", allocator);//ep1-1 quest ���� �̹���
			uquest2.AddMember("questname", "quest3npc3", allocator);//quest �̸� Ȥ�� �±׷� ��밡��
			uquest0.AddMember("condition", 3, allocator);//����Ʈ ����
			uquest0.AddMember("nowing", 0, allocator);//����Ʈ ���� ���������Ȳ
			uquest2.AddMember("rwrdcash", 10, allocator);//rewardcash �����
			uquest2.AddMember("rwrdExp", 10, allocator);//rewardExp ����ġ����
			uquest2.AddMember("rwrdhp", 10, allocator);//rewardhp hp����(����)

			userquest.PushBack(uquest2, allocator);



			rapidjson::Value useritem(kArrayType);//����ڰ� ������ item����� �迭�� ����

			rapidjson::Value uitem0;

			rapidjson::Value numV;

			uitem0.SetObject();
			numV.SetInt(999);
			uitem0.AddMember("keyid", numV, allocator);
			numV.SetInt(0);
			uitem0.AddMember("holding", numV, allocator);//���� ����


			useritem.PushBack(uitem0, allocator);

			rapidjson::Value uitem1;

			uitem1.SetObject();
			numV.SetInt(999);
			uitem1.AddMember("keyid", numV, allocator);
			numV.SetInt(0);
			uitem1.AddMember("holding", numV, allocator);//���� ����

			useritem.PushBack(uitem1, allocator);


			rapidjson::Value uitem2;

			uitem2.SetObject();
			numV.SetInt(999);
			uitem2.AddMember("keyid", numV, allocator);
			numV.SetInt(0);
			uitem2.AddMember("holding", numV, allocator);//���� ����

			useritem.PushBack(uitem2, allocator);

			rapidjson::Value uitem3;

			uitem3.SetObject();
			numV.SetInt(999);
			uitem3.AddMember("keyid", numV, allocator);
			numV.SetInt(0);
			uitem3.AddMember("holding", numV, allocator);//���� ����


			useritem.PushBack(uitem3, allocator);


			rapidjson::Value userpotion(kArrayType);//����ڰ� ������ item����� �迭�� ����

			rapidjson::Value upotion0;

			rapidjson::Value numP;

			upotion0.SetObject();
			numP.SetInt(999);
			upotion0.AddMember("keyid", numP, allocator);
			numP.SetInt(0);
			upotion0.AddMember("holding", numP, allocator);//���� ����


			userpotion.PushBack(upotion0, allocator);

			rapidjson::Value upotion1;

			upotion1.SetObject();
			numP.SetInt(999);
			upotion1.AddMember("keyid", numP, allocator);
			numP.SetInt(0);
			upotion1.AddMember("holding", numP, allocator);//���� ����


			userpotion.PushBack(upotion1, allocator);



			rapidjson::Value userweapon(kArrayType);//����ڰ� ������ item����� �迭�� ����

			rapidjson::Value uwp0;


			uwp0.SetObject();
			uwp0.AddMember("keyid", 999, allocator);//item �̸�

			numV.SetInt(0);
			uwp0.AddMember("holding", numV, allocator);//���� ����


			userweapon.PushBack(uwp0, allocator);

			rapidjson::Value uwp1;

			uwp1.SetObject();
			uwp1.AddMember("keyid", 999, allocator);//item �̸�

			numV.SetInt(0);
			uwp1.AddMember("holding", numV, allocator);//���� ����

			userweapon.PushBack(uwp1, allocator);

			rapidjson::Value uwp2;


			uwp2.SetObject();
			uwp2.AddMember("keyid", 999, allocator);//item �̸�

			numV.SetInt(0);
			uwp2.AddMember("holding", numV, allocator);//���� ����

			userweapon.PushBack(uwp2, allocator);

			rapidjson::Value uwp3;

			uwp3.SetObject();
			uwp3.AddMember("keyid", 999, allocator);//item �̸�

			numV.SetInt(0);
			uwp3.AddMember("holding", numV, allocator);//���� ����

			userweapon.PushBack(uwp3, allocator);

			initdoc.AddMember("userpotion", userpotion, allocator);//Document�� item�迭�� �߰�
			initdoc.AddMember("useritem", useritem, allocator);
			initdoc.AddMember("userquest", userquest, allocator);//Document�� quest�迭�� �߰�
			initdoc.AddMember("userweapon", userweapon, allocator);


			StringBuffer buffer;
			Writer<StringBuffer> writer(buffer);
			initdoc.Accept(writer);

			const char* schar = buffer.GetString();

			//log("Create JSON file success: %s", path.c_str());
			//log("data: %s", schar);

			fputs(schar, fp);
			fclose(fp);
		}
	}
}

std::string Jdata::jjgetuserName(int tag) {

	bool readflag = fileRead("data");
	if (!readflag) {
		//log("jjgetString failed");
		return "";
	}
	else
	{
		return doc["name"][tag].GetString();
	}
}

void Jdata::jjnameAppend(std::string ChaName) {
	//log("In Name Append");
	rapidjson::Document testData;

	std::string fpath = "C:\\json\\";
	//std::string fpath = FileUtils::sharedFileUtils()->getWritablePath();

	//fpath.append(fName);
	fpath.append("name.json");

	Data data = FileUtils::getInstance()->getDataFromFile(fpath);
	ssize_t size = data.getSize();
	//log("path: %s", fpath.c_str());

	char* jsonBuffer = new char[size + 1];
	memcpy(jsonBuffer, data.getBytes(), size);
	jsonBuffer[size] = '\0';
	data.clear();

	if (testData.ParseInsitu<0>(jsonBuffer).HasParseError() == false)
	{
		//log("In Name Append parse");
		rapidjson::Value& plyrlist = testData["name"];

		rapidjson::Document::AllocatorType& challocator = testData.GetAllocator();

		rapidjson::Value chaName;
		char buff[10];

		int len = sprintf(buff, "%s", ChaName.c_str());
		chaName.SetString(buff, len, challocator);
		memset(buff, 0, sizeof(buff));
		bool pexist = false;

		assert(plyrlist.IsArray());
		SizeType i = 0;
		for (i = 0; i < plyrlist.Size(); i++) {
			if (plyrlist[i].GetString() == ChaName) {
				pexist = true;
			}
		}

		if (pexist == false) {
			plyrlist.PushBack(chaName, challocator);
		}
	}
	else
	{
		CCASSERT(false, "ModifyArray type Parse json failed");
	}
	FILE* fpointer = fopen(fpath.c_str(), "wb+");

	StringBuffer b;
	Writer<StringBuffer> writer(b);
	testData.Accept(writer);

	std::string fData = b.GetString();
	const char* schar = fData.c_str();

	//log("data: %s", fData.c_str());
	//log("data: %s", schar);

	fputs(fData.c_str(), fpointer);
	fclose(fpointer);

}

void Jdata::jjnamelist() {

	std::string path = "C:\\json\\";
	//std::string path = FileUtils::sharedFileUtils()->getWritablePath();

	//path.append(fName);
	path.append("name.json");

	//bool fexist = FileUtils::sharedFileUtils()->isDirectoryExist(path);
	bool fexist = FileUtils::sharedFileUtils()->isFileExist(path);

	if (fexist == true) {
		//log("file exist");
		//log("path : %s", path.c_str());
	}
	else {
		//log("no file, so file will created");
		//log("path : %s", path.c_str());

		FILE* fp = fopen(path.c_str(), "wb+");//write�� ����� ������ ������ �ڵ������մϴ�.

		if (!fp) {
			//log("cannot create file: %s", path);
		}
		else {
			//log("JSON Append Test");

			Document userdoc;
			userdoc.SetObject();
			rapidjson::Document::AllocatorType& ualloca = userdoc.GetAllocator();

			rapidjson::Value plyrdata(kArrayType);

			userdoc.AddMember("name", plyrdata, ualloca);

			StringBuffer buffer;

			Writer<StringBuffer> writer(buffer);
			userdoc.Accept(writer);

			const char* schar = buffer.GetString();

			//log("Create JSON file success: %s", path.c_str());
			//log("Userdata: %s", schar);

			fputs(schar, fp);
			fclose(fp);
		}
	}
}

void Jdata::jjnamedelete(std::string name) {
	log("In Name delete");
	rapidjson::Document testData;

	std::string fpath = "C:\\json\\";
	//std::string fpath = FileUtils::sharedFileUtils()->getWritablePath();

	//fpath.append(fName);
	fpath.append("name.json");

	Data data = FileUtils::getInstance()->getDataFromFile(fpath);
	ssize_t size = data.getSize();
	//log("path: %s", fpath.c_str());

	char* jsonBuffer = new char[size + 1];
	memcpy(jsonBuffer, data.getBytes(), size);
	jsonBuffer[size] = '\0';
	data.clear();

	if (testData.ParseInsitu<0>(jsonBuffer).HasParseError() == false)
	{
	}
	else {

	}
}

//���� ������� �ʴ� �Լ�
void Jdata::jjplyrlist(std::string fName) {

	std::string path = "C:\\json\\";
	//std::string path = FileUtils::sharedFileUtils()->getWritablePath();

	path.append("name.json");
	//log("path: %s", path.c_str());

	FILE* fp = fopen(path.c_str(), "wb+");

	if (!fp) {
		//log("cannot create file: %s", path);
	}
	else {
		//log("JSON Append Test");

		Document ddoc;
		ddoc.SetObject();
		rapidjson::Document::AllocatorType& allocator = ddoc.GetAllocator();

		rapidjson::Value userdata(kArrayType);
		/*
		rapidjson::Value userlist0;

		char buff[10];
		buff[0] = '\0';
		int len = sprintf(buff, "%s", fName.c_str());
		userlist0.SetString(buff, len, allocator);
		memset(buff, 0, sizeof(buff));

		userdata.PushBack(userlist0, allocator);

		rapidjson::Value userlist1;

		len = sprintf(buff, "%s", "yoonmin");
		userlist1.SetString(buff, len, allocator);
		memset(buff, 0, sizeof(buff));

		userdata.PushBack(userlist1, allocator);
		*/
		ddoc.AddMember("name", userdata, allocator);

		rapidjson::Value hasCharacter;

		StringBuffer buffer;

		Writer<StringBuffer> writer(buffer);
		ddoc.Accept(writer);


		const char* schar = buffer.GetString();

		//log("Create JSON file success: %s", path.c_str());
		//log("data: %s", schar);

		fputs(schar, fp);
		fclose(fp);
	}
}

void Jdata::jjPotionAppend() {

	std::string path = "C:\\json\\";
	//std::string path = FileUtils::sharedFileUtils()->getWritablePath();

	path.append("potion.json");//������ �ڵ������ϵ��� �մϴ�.
							   //log("path: %s", path.c_str());

	FILE* fp = fopen(path.c_str(), "wb+");


	if (!fp) {
		//log("cannot create file: %s", path);
	}
	else {
		//log("JSON Append Test");

		Document potiondoc;
		potiondoc.SetObject();
		rapidjson::Document::AllocatorType& allocator = potiondoc.GetAllocator();

		rapidjson::Value potion(kArrayType);

		rapidjson::Value hp;
		hp.SetObject();
		hp.AddMember("png", "hppotion.png", allocator);
		hp.AddMember("pngname", "store_hp(s).png", allocator);
		hp.AddMember("effect", 100, allocator);
		hp.AddMember("money", 1000, allocator);
		hp.AddMember("keyid", 0, allocator);
		hp.AddMember("infoimg", "hpinfo.png", allocator);
		hp.AddMember("infostr", "red effect 100 money 1000", allocator);

		potion.PushBack(hp, allocator);

		rapidjson::Value mp;
		mp.SetObject();
		mp.AddMember("png", "mppotion.png", allocator);
		mp.AddMember("pngname", "store_mp(s).png", allocator);
		mp.AddMember("effect", 100, allocator);
		mp.AddMember("money", 1100, allocator);
		mp.AddMember("keyid", 1, allocator);
		mp.AddMember("infoimg", "mpinfo.png", allocator);
		mp.AddMember("infostr", "blue effect 100 money 1100", allocator);

		potion.PushBack(mp, allocator);

		potiondoc.AddMember("potion", potion, allocator);

		/*
		rapidjson::Value weapon(kArrayType);

		rapidjson::Value w1;
		w1.SetObject();
		w1.AddMember("pngname", "store_hp(s).png", allocator);
		w1.AddMember("effect", 100, allocator);
		w1.AddMember("money", 1000, allocator);
		w1.AddMember("infoimg", "redinfo.png", allocator);
		w1.AddMember("infostr", "red effect 100 money 1000", allocator);

		weapon.PushBack(w1, allocator);

		rapidjson::Value w2;
		w2.SetObject();
		w2.AddMember("pngname", "store_mp(s).png", allocator);
		w2.AddMember("effect", 100, allocator);
		w2.AddMember("money", 1100, allocator);
		w2.AddMember("infoimg", "blueinfo.png", allocator);
		w2.AddMember("infostr", "blue effect 100 money 1100", allocator);

		weapon.PushBack(w2, allocator);

		potiondoc.AddMember("weapon", weapon, allocator);
		*/
		StringBuffer buffer;
		Writer<StringBuffer> writer(buffer);
		potiondoc.Accept(writer);

		const char* schar = buffer.GetString();

		//log("Create JSON file success: %s", path.c_str());
		//log("data: %s", schar);

		fputs(schar, fp);
		fclose(fp);
	}
}

void Jdata::jjWeaponAppend() {

	std::string path = "C:\\json\\";
	//std::string path = FileUtils::sharedFileUtils()->getWritablePath();

	path.append("weapon.json");//������ �ڵ������ϵ��� �մϴ�.
							   //log("path: %s", path.c_str());

	FILE* fp = fopen(path.c_str(), "wb+");


	if (!fp) {
		//log("cannot create file: %s", path);
	}
	else {
		//log("JSON Append Test");

		Document weapondoc;
		weapondoc.SetObject();
		rapidjson::Document::AllocatorType& allocator = weapondoc.GetAllocator();

		rapidjson::Value weapon(kArrayType);

		rapidjson::Value item0;
		item0.SetObject();
		item0.AddMember("shoppng", "store_wp1.png", allocator);
		item0.AddMember("pngname", "wp1.png", allocator);
		item0.AddMember("effect", 25, allocator);//�������� �� ���ݷ�
		item0.AddMember("money", 4000, allocator);
		item0.AddMember("keyid", 0, allocator);
		item0.AddMember("infoimg", "wp1info.png", allocator);//�̹����� �����Ƿ� �����̹����� ��ü

		weapon.PushBack(item0, allocator);


		rapidjson::Value item1;
		item1.SetObject();
		item1.AddMember("shoppng", "store_shirts1.png", allocator);
		item1.AddMember("pngname", "shirts1.png", allocator);
		item1.AddMember("effect", 10, allocator);//�������� �� ���ݷ�
		item1.AddMember("money", 3500, allocator);
		item1.AddMember("keyid", 1, allocator);
		item1.AddMember("infoimg", "sh1info.png", allocator);//�̹����� �����Ƿ� �����̹����� ��ü

		weapon.PushBack(item1, allocator);

		rapidjson::Value item2;
		item2.SetObject();
		item2.AddMember("shoppng", "store_pants1.png", allocator);
		item2.AddMember("pngname", "pants1.png", allocator);
		item2.AddMember("effect", 7, allocator);//�������� �� ���ݷ�
		item2.AddMember("money", 3300, allocator);
		item2.AddMember("keyid", 2, allocator);
		item2.AddMember("infoimg", "pa2info.png", allocator);//�̹����� �����Ƿ� �����̹����� ��ü

		weapon.PushBack(item2, allocator);

		weapondoc.AddMember("weapon", weapon, allocator);

		StringBuffer buffer;
		Writer<StringBuffer> writer(buffer);
		weapondoc.Accept(writer);

		const char* schar = buffer.GetString();

		fputs(schar, fp);
		fclose(fp);
	}
}
void Jdata::jjItemAppend() {

	std::string path = "C:\\json\\";
	//std::string path = FileUtils::sharedFileUtils()->getWritablePath();

	path.append("item.json");//������ �ڵ������ϵ��� �մϴ�.
							 //log("path: %s", path.c_str());

	FILE* fp = fopen(path.c_str(), "wb+");


	if (!fp) {
		//log("cannot create file: %s", path);
	}
	else {
		//log("JSON Append Test");

		Document itemdoc;
		itemdoc.SetObject();
		rapidjson::Document::AllocatorType& allocator = itemdoc.GetAllocator();

		rapidjson::Value item(kArrayType);

		rapidjson::Value item0;
		item0.SetObject();
		item0.AddMember("name", "item1.png", allocator);
		item0.AddMember("png", 25, allocator);//�������� �� ���ݷ�
		item0.AddMember("sellmoney", 500, allocator);
		item0.AddMember("keyid", 0, allocator);


		item.PushBack(item0, allocator);



		itemdoc.AddMember("item", item, allocator);

		StringBuffer buffer;
		Writer<StringBuffer> writer(buffer);
		itemdoc.Accept(writer);

		const char* schar = buffer.GetString();

		fputs(schar, fp);
		fclose(fp);
	}
}
void Jdata::jjSkillAppend() {

	std::string path = "C:\\json\\";
	//std::string path = FileUtils::sharedFileUtils()->getWritablePath();

	path.append("skill.json");//������ �ڵ������ϵ��� �մϴ�.
							  //log("path: %s", path.c_str());

	FILE* fp = fopen(path.c_str(), "wb+");


	if (!fp) {
		//log("cannot create file: %s", path);
	}
	else {
		//log("JSON Append Test");

		Document skilldoc;
		skilldoc.SetObject();
		rapidjson::Document::AllocatorType& allocator = skilldoc.GetAllocator();

		rapidjson::Value skill(kArrayType);

		rapidjson::Value skill0;
		skill0.SetObject();

		skill0.AddMember("effect", 120, allocator);
		skill0.AddMember("keyid", 0, allocator);


		skill.PushBack(skill0, allocator);



		skilldoc.AddMember("skill", skill, allocator);

		StringBuffer buffer;
		Writer<StringBuffer> writer(buffer);
		skilldoc.Accept(writer);

		const char* schar = buffer.GetString();

		fputs(schar, fp);
		fclose(fp);
	}
}

void Jdata::writetoFile(std::string fName) {
	std::string path = "C:\\json\\";
	//std::string path = FileUtils::sharedFileUtils()->getWritablePath();

	path.append(fName);
	path.append(".json");
	//log("path: %s", path.c_str());

	FILE* fp = fopen(path.c_str(), "wb");

	if (!fp) {
		//log("can not open file %s", path.c_str());
	}
	else
	{
		Writer<StringBuffer> writer(writeBuffer);
		doc.Accept(writer);

		std::string fData = writeBuffer.GetString();
		//log("buffffffffer: %s\n", writeBuffer.GetString());
		const char* schar = fData.c_str();

		//log("write file success: %s", path.c_str());
		//log("data: %s", fData.c_str());

		fputs(fData.c_str(), fp);
		fclose(fp);
	}
}

//dataparsing
//test�� �ڵ� �����¿��� ����� -> Jdata������ ����
//������� �迭Ÿ���� potion value �� bool�̶� int ���� �����ϰ�, string ���� ���ǹ����� Ȯ���ϴ� �Լ��� �θ���.
void Jdata::modifyParray(std::string fName) {


	//log("In Modify Potion Array function");
	rapidjson::Document testData;
	std::string fpath = "C:\\json\\";
	//std::string fpath = FileUtils::sharedFileUtils()->getWritablePath();


	fpath.append(fName);
	fpath.append(".json");

	//log("path: %s", fpath.c_str());

	FILE* fp = fopen(fpath.c_str(), "wb+");

	Data data = FileUtils::getInstance()->getDataFromFile(fpath);
	ssize_t size = data.getSize();

	char* jsonBuffer = new char[size + 1];
	memcpy(jsonBuffer, data.getBytes(), size);
	jsonBuffer[size] = '\0';
	data.clear();
	if (testData.ParseInsitu<0>(jsonBuffer).HasParseError() == false)
	{
		//log("In ParseInsitu");
		const rapidjson::Value& dPotion = testData["userpotion"];//�迭�� ���۷��� ���

		rapidjson::Value& h = testData["userpotion"][0]["holding"]; //�迭Ÿ�Կ��� �ش�Ǵ� �� ������ ������

		assert(dPotion.IsArray());//�⺻������ �迭 ���θ� Ȯ��


								  //rapidjson::Value potion(kArrayType);
		rapidjson::Document::AllocatorType& allocator = testData.GetAllocator();

		rapidjson::Value hnum;
		hnum.SetInt(0);

		//hp.AddMember("pngname", "store_hp(s).png", allocator);
		//hp.AddMember("effect", 100, allocator);

		//for (SizeType i = 0; i < dPotion.Size(); i++)
		//{

		//log("%d", dPotion[0]["holding"].GetInt());
		hnum.SetInt(dPotion[0]["holding"].GetInt());

		h.SetInt(3);
		//log("hhhhhhhhhhhhhhhhhh-%d", h.GetInt());
		//dPotion.SetInt(3);

		//dPotion[0]["holding"].PushBack("holding",hnum, allocator);
		//}

		/*--------------0209 test before
		rapidjson::Document::AllocatorType& allocator = testData.GetAllocator();

		rapidjson::Value v;
		v.SetInt(1);


		//�迭�� ������� 0���� �����մϴ�. ���⼭ HP �±� ���� 0�̶� �迭�� 0��° HP�������� �ҷ��� �����Դϴ�.
		std::string pt = dPotion[0]["uitemname"].GetString();
		if (pt == "HP") {
		log("in if pt----------------------------------");
		}
		*/
	}
	else
	{
		CCASSERT(false, "ModifyArray type Parse json failed");
	}
	CC_SAFE_DELETE_ARRAY(jsonBuffer);


	StringBuffer buffer;
	Writer<StringBuffer> writer(buffer);
	testData.Accept(writer);

	const char* schar = buffer.GetString();
	std::string fData = buffer.GetString();

	//log("Create JSON file success: %s", fpath.c_str());
	//log("data: %s", schar);

	fputs(schar, fp);
	fclose(fp);

}

//dataparsing
//test�� �ڵ� �����¿��� ����� -> Jdata������ ����
//������� �迭Ÿ���� potion value �� bool�̶� int ���� �����ϰ�, string ���� ���ǹ����� Ȯ���ϴ� �Լ��� �θ���.
void Jdata::modifyParray2(std::string fName) {

	//log("In Modify Potion Array function");
	rapidjson::Document testData;

	std::string fpath = "C:\\json\\";
	//std::string fpath = FileUtils::sharedFileUtils()->getWritablePath();

	fpath.append(fName);
	fpath.append(".json");

	Data data = FileUtils::getInstance()->getDataFromFile(fpath);
	ssize_t size = data.getSize();
	//log("path: %s", fpath.c_str());

	char* jsonBuffer = new char[size + 1];
	memcpy(jsonBuffer, data.getBytes(), size);
	jsonBuffer[size] = '\0';
	data.clear();

	if (testData.ParseInsitu<0>(jsonBuffer).HasParseError() == false)
	{
		//log("In ParseInsitu");
		rapidjson::Value& dPotion = testData["userpotion"];//�迭�� ���۷��� ���
		rapidjson::Value& userquest = testData["userquset"];
		rapidjson::Value& h = testData["userpotion"][0]["holding"]; //�迭Ÿ�Կ��� �ش�Ǵ� �� ������ ������
		rapidjson::Value& b = userquest[0]["done"];//�̷� ������ ���۷����� Value&�� �����ؼ� ����մϴ�.
		rapidjson::Value& qn = userquest[0]["questname"];

		rapidjson::Document::AllocatorType& allocator = testData.GetAllocator();

		//log("%d", dPotion[0]["holding"].GetInt());

		h.SetInt(3);//���� ������
		b.SetBool(true);
		qn.SetString("ym.png");
		//log("hhhhhhhhhhhhhhhhhh-%d", h.GetInt());
	}
	else
	{
		CCASSERT(false, "ModifyArray type Parse json failed");
	}
	FILE* fpointer = fopen(fpath.c_str(), "wb+");

	StringBuffer b;
	Writer<StringBuffer> writer(b);
	testData.Accept(writer);

	std::string fData = b.GetString();
	const char* schar = fData.c_str();

	//log("data: %s", fData.c_str());
	//log("data: %s", schar);

	fputs(fData.c_str(), fpointer);
	fclose(fpointer);

}

