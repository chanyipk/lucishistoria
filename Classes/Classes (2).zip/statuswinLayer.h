#pragma once

#ifndef __statuswinL_H__
#define __statuswinL_H__
#define EXIT 0

#define STATUSW 1000

#include "cocos2d.h"

USING_NS_CC;

class statuswinLayer : public Layer
{
public:
	static Scene* createScene();
	virtual bool init();

	void closebut(Ref* sener);
	CREATE_FUNC(statuswinLayer);
};


#endif 
