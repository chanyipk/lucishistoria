#include "GameScene.h"
#include "UserLayer.h"
#include "dataSingleton.h"
#include "ElyonScene.h"
#include "Jdata.h"
#include "itemwinLayer.h"
#include "statuswinLayer.h"


Jdata* pL;

LabelTTF* redNUM;//����� �����ϸ� heap ���� �߻� + sprtie red ������ ��������
LabelTTF* blueNUM;



bool UserLayer::init() {
	if (!Layer::init()) {
		return false;
	}
	dataSingleton::getInstance()->risen = false;
	dataSingleton::getInstance()->winopen = false;
	dataSingleton::getInstance()->redcount = pL->jjgetpArray("holding", "test", 0); //json�� ���� ���� �����;� �Ѵ�.
	gameovertrue = false;
	playerDead = false;
	dataSingleton::getInstance()->skillpressedA = false;
	skilltime = false;


	auto bar = Sprite::create("userbar.png");
	bar->setAnchorPoint(Point(0, 0));
	bar->setPosition(Point(0, 0));
	this->addChild(bar);

	//	std::string Lv = "Lv. " ;
	level = pL->jjgetInt("level", "test");
	std::string levelnums = std::to_string(level);
	levelnumsTTF = LabelTTF::create("Lv." + levelnums, "Thonburi",25);
	levelnumsTTF->setPosition(Point(58, 58));
	levelnumsTTF->setAnchorPoint(Point(0.5, 0.5));
	this->addChild(levelnumsTTF);


	auto phps = Sprite::create("hpbar.png");
	PHPbar = ProgressTimer::create(phps);
	PHPbar->setType(ProgressTimer::Type::BAR);
	PHPbar->setAnchorPoint(Point(0, 0));
	PHPbar->setPosition(Point(113, 74));
	PHPbar->setMidpoint(Point(0, 0));
	PHPbar->setBarChangeRate(Point(1, 0));
	PHPbar->setPercentage(100);
	this->addChild(PHPbar);

	std::string hpnums = std::to_string(pL->jjgetInt("hp", "test"));
	hpnumsTTF = LabelTTF::create(hpnums, "Thonburi", 18);
	hpnumsTTF->setPosition(Point(280, 15));
	PHPbar->addChild(hpnumsTTF);

	PHP = pL->jjgetInt("hp", "test");
	dataSingleton::getInstance()->pHP = PHP;


	auto pmps = Sprite::create("mpbar.png");
	PMPbar = ProgressTimer::create(pmps);
	PMPbar->setType(ProgressTimer::Type::BAR);
	PMPbar->setAnchorPoint(Point(0, 0));
	PMPbar->setPosition(Point(113, 41));
	PMPbar->setMidpoint(Point(0, 0));
	PMPbar->setBarChangeRate(Point(1, 0));
	PMPbar->setPercentage(100);
	this->addChild(PMPbar);

	std::string mpnums = std::to_string(pL->jjgetInt("mp", "test"));
	mpnumsTTF = LabelTTF::create(mpnums, "Thonburi", 18);
	mpnumsTTF->setPosition(Point(280, 15));
	PMPbar->addChild(mpnumsTTF);

	PMP = pL->jjgetInt("mp", "test");
	dataSingleton::getInstance()->pMP = PMP;

	auto PEXPs = Sprite::create("expbar.png");
	PEXPbar = ProgressTimer::create(PEXPs);
	PEXPbar->setType(ProgressTimer::Type::BAR);
	PEXPbar->setAnchorPoint(Point(0, 0));
	PEXPbar->setPosition(Point(113, 8));
	PEXPbar->setMidpoint(Point(0, 0));
	PEXPbar->setBarChangeRate(Point(1, 0));
	PEXPbar->setPercentage(0);
	this->addChild(PEXPbar);

	std::string expnums = std::to_string(pL->jjgetInt("exp", "test"));
	expnumsTTF = LabelTTF::create(expnums, "Thonburi", 18);
	expnumsTTF->setPosition(Point(280, 15));
	PEXPbar->addChild(expnumsTTF);

	maxPEXP = pL->jjgetInt("maxexp", "test");
	PEXP = pL->jjgetInt("exp", "test");//json���� ���� �����;� �ҵ�
	dataSingleton::getInstance()->pEXP = PEXP;

	skillbox1 = Sprite::create("userbox.png");
	skillbox1->setAnchorPoint(Point(0.5, 0.5));
	skillbox1->setPosition(Point(800, 55));
	this->addChild(skillbox1);

	auto skillbox2 = Sprite::create("userbox.png");
	skillbox2->setAnchorPoint(Point(0.5, 0.5));
	skillbox2->setPosition(Point(914, 55));
	this->addChild(skillbox2);

	auto skillbox3 = Sprite::create("userbox.png");
	skillbox3->setAnchorPoint(Point(0.5, 0.5));
	skillbox3->setPosition(Point(1028, 55));
	this->addChild(skillbox3);

	auto skillbox4 = Sprite::create("userbox.png");
	skillbox4->setAnchorPoint(Point(0.5, 0.5));
	skillbox4->setPosition(Point(1142, 55));
	this->addChild(skillbox4);

	auto itembox1 = Sprite::create("userbox.png");
	itembox1->setAnchorPoint(Point(0.5, 0.5));
	itembox1->setPosition(Point(1397, 55));
	this->addChild(itembox1);

	auto itembox2 = Sprite::create("userbox.png");
	itembox2->setAnchorPoint(Point(0.5, 0.5));
	itembox2->setPosition(Point(1511, 55));
	this->addChild(itembox2);

	auto itembox3 = Sprite::create("userbox.png");
	itembox3->setAnchorPoint(Point(0.5, 0.5));
	itembox3->setPosition(Point(1625, 55));
	this->addChild(itembox3);

	auto itembox4 = Sprite::create("userbox.png");
	itembox4->setAnchorPoint(Point(0.5, 0.5));
	itembox4->setPosition(Point(1739, 55));
	this->addChild(itembox4);

	auto itembox5 = Sprite::create("userbox.png");
	itembox5->setAnchorPoint(Point(0.5, 0.5));
	itembox5->setPosition(Point(1853, 55));
	this->addChild(itembox5);

	
		auto sid1 = pL->jjgetInt("skill1", "test");
		if (sid1 != 999) {
			auto skillfile = pL->jjgetSAry("png", "skill", "skill", sid1);
			auto skill1_img = Sprite::create(skillfile);
			skill1_img->setAnchorPoint(Point(0.5, 0.5));
			skill1_img->setPosition(Point(47, 48));
			skillbox1->addChild(skill1_img);
		}

		auto skillLabel1 = LabelTTF::create("A", "Thonburi", 18);
		skillLabel1->setPosition(Point(80, 15));
		skillbox1->addChild(skillLabel1);


		auto skillLabel2 = LabelTTF::create("S", "Thonburi", 18);
		skillLabel2->setPosition(Point(80, 15));
		skillbox2->addChild(skillLabel2);

		auto skillLabel3 = LabelTTF::create("D", "Thonburi", 18);
		skillLabel3->setPosition(Point(80, 15));
		skillbox3->addChild(skillLabel3);

		auto skillLabel4 = LabelTTF::create("F", "Thonburi", 18);
		skillLabel4->setPosition(Point(80, 15));
		skillbox4->addChild(skillLabel4);


	/*
	auto skillbox1 = Sprite::create("box.png");
	skillbox1->setAnchorPoint(Point(0.5, 0.5));
	skillbox1->setPosition(Point(1200, 80));
	skillbox1->setScale(0.8);
	this->addChild(skillbox1);

	auto skill1_img = Sprite::create("skill1_img.png");
	skill1_img->setAnchorPoint(Point(0.5, 0.5));
	skill1_img->setPosition(Point(1200, 80));
	skill1_img->setScale(0.8);
	this->addChild(skill1_img);

	auto box1 = Sprite::create("box.png");
	box1->setAnchorPoint(Point(0.5, 0.5));
	box1->setPosition(Point(1300, 80));
	box1->setScale(0.8);
	this->addChild(box1);

	auto box2 = Sprite::create("box.png");
	box2->setAnchorPoint(Point(0.5, 0.5));
	box2->setPosition(Point(1400, 80));
	box2->setScale(0.8);
	this->addChild(box2);

	auto box3 = Sprite::create("box.png");
	box3->setAnchorPoint(Point(0.5, 0.5));
	box3->setPosition(Point(1500, 80));
	box3->setScale(0.8);
	this->addChild(box3);

	auto box4 = Sprite::create("box.png");
	box4->setAnchorPoint(Point(0.5, 0.5));
	box4->setPosition(Point(1600, 80));
	box4->setScale(0.8);
	this->addChild(box4);

	auto box5 = Sprite::create("box.png");
	box5->setAnchorPoint(Point(0.5, 0.5));
	box5->setPosition(Point(1700, 80));
	box5->setScale(0.8);
	this->addChild(box5);


	auto box6 = Sprite::create("box.png");
	box6->setAnchorPoint(Point(0.5, 0.5));
	box6->setPosition(Point(1800, 80));
	box6->setScale(0.8);
	this->addChild(box6);
	*/

	auto stat_but = MenuItemImage::create("cirbut.png", "cirbut_push.png", CC_CALLBACK_1(UserLayer::button, this));
	stat_but->setTag(statb);
	auto stat = Menu::create(stat_but, NULL);
	stat->setAnchorPoint(Point(0.5, 0.5));
	stat->setPosition(Point(1200, 630));
	stat->setScale(0.35);
	this->addChild(stat);

	auto item_but = MenuItemImage::create("cirbut.png", "cirbut_push.png", CC_CALLBACK_1(UserLayer::button, this));
	item_but->setTag(itemb);
	auto item = Menu::create(item_but, NULL);
	item->setAnchorPoint(Point(0.5, 0.5));
	item->setPosition(Point(1200, 510));
	item->setScale(0.35);
	this->addChild(item);

	auto skill_but = MenuItemImage::create("cirbut.png", "cirbut_push.png", CC_CALLBACK_1(UserLayer::button, this));
	skill_but->setTag(skillb);
	auto skill = Menu::create(skill_but, NULL);
	skill->setAnchorPoint(Point(0.5, 0.5));
	skill->setPosition(Point(1200, 390));
	skill->setScale(0.35);
	this->addChild(skill);

	auto quest_but = MenuItemImage::create("cirbut.png", "cirbut_push.png", CC_CALLBACK_1(UserLayer::button, this));
	quest_but->setTag(questb);
	auto quest = Menu::create(quest_but, NULL);
	quest->setAnchorPoint(Point(0.5, 0.5));
	quest->setPosition(Point(1200, 270));
	quest->setScale(0.35);
	this->addChild(quest);


	/*	auto back_but = MenuItemImage::create("cirbut.png", "cirbut_push.png", CC_CALLBACK_1(UserLayer::button, this));
	back_but->setTag(backb);
	auto back = Menu::create(back_but, NULL);
	back->alignItemsVertically();
	back->setAnchorPoint(Point(0.5, 0.5));
	back->setPosition(Point(1200, 150));
	back->setVisible(false);
	back->setScale(0.35);
	this->addChild(back);


	auto exit_but = MenuItemImage::create("cirbut.png", "cirbut_push.png", CC_CALLBACK_1(UserLayer::button, this));
	exit_but->setTag(exitb);
	auto exit = Menu::create(exit_but, NULL);
	exit->alignItemsVertically();
	exit->setAnchorPoint(Point(0.5, 0.5));
	exit->setPosition(Point(1200,150));
	exit->setScale(0.35);
	exit->setVisible(false);
	this->addChild(exit);


	if (dataSingleton::getInstance()->elyonScene) {
	exit->setVisible(true);
	back->setVisible(false);
	}
	else{
	exit->setVisible(false);
	back->setVisible(true);
	}
	*/
	//HP����
	/*red = Sprite::create("hppotion.png");
	red->setTag(RED);
	red->setPosition(Point(1300, 80));
	red->setVisible(false);
	this->addChild(red);
	*/
	auto redspr = MenuItemImage::create("hppotion.png", "hppotion.png", CC_CALLBACK_1(UserLayer::onSprTouchBegan, this));
	red = Menu::create(redspr, NULL);
	red->setPosition(Point(50, 50));
	red->setVisible(false);
	itembox1->addChild(red);

	//	std::string red_c = std::to_string(pL->jjgetInt("red_count", "test"));
	redNUM = LabelTTF::create("0", "Thonburi", 18);
	redNUM->setPosition(Point(80, 15));
	redNUM->setVisible(false);
	itembox1->addChild(redNUM);

	auto bluespr = MenuItemImage::create("mppotion.png", "mppotion.png", CC_CALLBACK_1(UserLayer::onSprTouchBegan2, this));
	blue = Menu::create(bluespr, NULL);
	blue->setPosition(Point(50, 50));
	blue->setVisible(false);
	itembox2->addChild(blue);

	blueNUM = LabelTTF::create("0", "Thonburi", 18);
	blueNUM->setPosition(Point(80, 15));
	blueNUM->setVisible(false);
	itembox2->addChild(blueNUM);


	this->scheduleUpdate();

	return true;
}

void UserLayer::update(float delta) {


	redpotion();

	PHP = dataSingleton::getInstance()->pHP;
	if (PHP <= 0)
		PHP = 0;
	auto maxhp = pL->jjgetInt("maxhp", "test");
	auto hpcu = (PHP / maxhp) * 100; //1000�κ��� ������ �ʴ� ĳ���� ü�� �� ������ �־�� ��
	PHPbar->setPercentage(hpcu);
	String *hpstr = String::createWithFormat("%.0f", PHP);
	hpnumsTTF->setString(hpstr->getCString());

	PMP = dataSingleton::getInstance()->pMP;
	auto maxmp = pL->jjgetInt("maxmp", "test");
	auto mpcu = (PMP / maxmp) * 100;
	PMPbar->setPercentage(mpcu);
	String *mpstr = String::createWithFormat("%.0f", PMP);
	mpnumsTTF->setString(mpstr->getCString());

	PEXP = dataSingleton::getInstance()->pEXP;

	//levelup
	if (PEXP >= maxPEXP) {
		PEXP = PEXP - maxPEXP;
		dataSingleton::getInstance()->pEXP = PEXP;

		levelupeffect();
		level = level + 1;
		pL->jjsetInt(level, "level", "test");
		String *levelStr = String::createWithFormat("Lv\.%d", level);
		levelnumsTTF->setString(levelStr->getCString());

		auto maxhp = pL->jjgetInt("maxhp", "test");
		maxhp = maxhp + maxhp*0.15;
		pL->jjsetInt(maxhp, "maxhp", "test");
		pL->jjsetInt(maxhp, "hp", "test");
		PHP = maxhp;
		dataSingleton::getInstance()->pHP = PHP;

		auto maxmp = pL->jjgetInt("maxmp", "test");
		maxmp = maxmp + maxmp*0.15;
		pL->jjsetInt(maxmp, "maxmp", "test");
		pL->jjsetInt(maxhp, "mp", "test");
		PMP = maxmp;
		dataSingleton::getInstance()->pMP = PMP;
		auto maxexp = pL->jjgetInt("maxexp", "test");
		maxexp = maxexp + maxexp*0.3;
		pL->jjsetInt(maxexp, "maxexp", "test");
		maxPEXP = maxexp;

		auto wid = pL->jjgetInt("wweapon", "test");
		auto sid = pL->jjgetInt("wshirts", "test");
		auto pid = pL->jjgetInt("wpants", "test");
		auto atk = pL->jjgetInt("atk", "test");
		
		if (wid == 999)
			atk = atk + atk*0.2;
		else {
			auto watk = pL->jjgetAry("effect", "weapon", "weapon", wid);
			atk = (atk - watk)*0.2;
			atk = atk + watk;
		}
		pL->jjsetInt(atk, "atk", "test");

		auto def = pL->jjgetInt("def", "test");
		if (sid == 999 && pid == 999)
			def = def + def*0.18;
		else if (sid != 999 && pid == 999) {
			auto sdef = pL->jjgetAry("effect", "weapon", "weapon", sid);
			def = (def - sdef)*0.18;
			def = def + sdef;
		}
		else if (sid == 999 && pid != 999) {
			auto pdef = pL->jjgetAry("effect", "weapon", "weapon", pid);
			def = (def - pdef)*0.18;
			def = def + pdef;
		}
		else {
			auto sdef = pL->jjgetAry("effect", "weapon", "weapon", wid);
			auto pdef = pL->jjgetAry("effect", "weapon", "weapon", pid);
			def = (def - sdef - pdef)*0.18;
			def = def + sdef + pdef;
		}
		pL->jjsetInt(def, "def", "test");
		//���⿡ �������� �ؾ���
	}

	float expcu = (PEXP / maxPEXP) * 100;
	PEXPbar->setPercentage(expcu);
	String *expstr = String::createWithFormat("%.2f%%", expcu);
	expnumsTTF->setString(expstr->getCString());

	if (dataSingleton::getInstance()->skillpressedA && !skilltime) {//��ųA�� ���� ��Ÿ��
		skilltime = true;

		auto skillid = pL->jjgetInt("skill1", "test");
		auto cooltime = pL->jjgetAry("cooltime", "skill", "skill", skillid);
		ProgressTo *to1 = ProgressTo::create(cooltime, 0);
		ProgressTimer* progress1 = ProgressTimer::create(Sprite::create("skilling.png"));

		progress1->setType(kCCProgressTimerTypeRadial);
		progress1->setPosition(Point(47, 48));

		progress1->setPercentage(100);
		skillbox1->addChild(progress1);
		progress1->runAction(RepeatForever::create(to1));

		addLabelTimer(skillbox1, cooltime+1, Vec2(48, 48));  // ȣ������� ���� Ÿ�̸� �θ� �� ����
	}

	playerDead = dataSingleton::getInstance()->playerDead;
	
	if (playerDead && !gameovertrue && !dataSingleton::getInstance()->elyonScene)
		gameover();
}

void UserLayer::redpotion() {

	auto redcount = pL->jjgetpArray("holding", "test", 0);//json�� ���� �����;���
	dataSingleton::getInstance()->redcount = redcount;

	if (redcount == 0) {

		red->setVisible(false);
		redNUM->setVisible(false);

	}
	else if (redcount > 0) {//json�� ���� �����;���


		redNUM->setVisible(true);
		String *str = String::createWithFormat("%d", redcount);
		redNUM->setString(str->getCString());


		if (!red->isVisible()) {
			red->setVisible(true);
		}

	}
	auto bluecount = pL->jjgetpArray("holding", "test", 1);//json�� ���� �����;���
	dataSingleton::getInstance()->bluecount = bluecount;

	if (bluecount == 0) {

		blue->setVisible(false);
		blueNUM->setVisible(false);

	}
	else if (bluecount > 0) {//json�� ���� �����;���


		blueNUM->setVisible(true);
		String *str = String::createWithFormat("%d", bluecount);
		blueNUM->setString(str->getCString());


		if (!blue->isVisible()) {
			blue->setVisible(true);
		}

	}

}
//������ ��� �Լ�
void UserLayer::onSprTouchBegan(Ref* sender)
{
	auto maxPHP = pL->jjgetInt("maxhp", "test");
	if (dataSingleton::getInstance()->redcount > 0 && PHP>0 && PHP<maxPHP) {
		dataSingleton::getInstance()->redcount -= 1;
	
		if (PHP + 200>maxPHP)
			dataSingleton::getInstance()->pHP = maxPHP;
		else
			dataSingleton::getInstance()->pHP = dataSingleton::getInstance()->pHP + 200;
		pL->jjsetpArray("holding", "test", dataSingleton::getInstance()->redcount, 0);
		pL->jjsetInt(dataSingleton::getInstance()->pHP, "hp", "test");
	}
}
void UserLayer::onSprTouchBegan2(Ref* sender)
{
	auto maxPMP = pL->jjgetInt("maxmp", "test");
	if (dataSingleton::getInstance()->bluecount > 0 && PMP>0 && PMP<maxPMP) {
		dataSingleton::getInstance()->bluecount -= 1;
		if (PMP + 200>maxPMP)
			dataSingleton::getInstance()->pMP = maxPMP;
		else
			dataSingleton::getInstance()->pMP = dataSingleton::getInstance()->pMP + 200;
		pL->jjsetpArray("holding", "test", dataSingleton::getInstance()->bluecount, 1);
		pL->jjsetInt(dataSingleton::getInstance()->pMP, "mp", "test");
	}
}

void UserLayer::gameover() {

	gameovertrue = true;
	auto background = Sprite::create("gameover_back.png");
	background->setAnchorPoint(Point(0, 0));
	background->setPosition(Point(0, 0));
	background->setTag(BACK);
	this->addChild(background);


	auto magic1 = Sprite::create("magicside.png");
	magic1->setAnchorPoint(Point(0.5, 0.5));
	magic1->setPosition(Point(960, 530));
	magic1->setTag(MAGIC1);
	this->addChild(magic1);
	auto rotate1 = RotateBy::create(20.0f, 360.0f);
	auto repeat1 = RepeatForever::create(rotate1);
	magic1->runAction(repeat1);

	auto magic2 = Sprite::create("magiccenter.png");
	magic2->setAnchorPoint(Point(0.5, 0.5));
	magic2->setPosition(Point(960, 530));
	magic2->setTag(MAGIC2);
	this->addChild(magic2);
	auto rotate2 = RotateBy::create(20.0f, -360.0f);
	auto repeat2 = RepeatForever::create(rotate2);
	magic2->runAction(repeat2);

	auto risenwin = Sprite::create("risen.png");
	risenwin->setAnchorPoint(Point(0.5, 0.5));
	risenwin->setPosition(Point(960, 700));
	risenwin->setTag(RISE_WIN);
	this->addChild(risenwin);

	auto risenbut = MenuItemImage::create("risenbut.png", "risenbut_push.png", CC_CALLBACK_1(UserLayer::risenpush, this));
	auto shiftbut = MenuItemImage::create("shiftbut.png", "shiftbut_push.png", CC_CALLBACK_1(UserLayer::shiftpush, this));

	risenbut->setTag(RISEN);
	shiftbut->setTag(SHIFT);
	auto but_1 = Menu::create(risenbut, NULL);
	but_1->alignItemsVertically();
	but_1->setAnchorPoint(Point(0, 0));
	but_1->setPosition(Point(750, 450));
	but_1->setTag(BUT_1);
	this->addChild(but_1);

	auto but_2 = Menu::create(shiftbut, NULL);
	but_2->alignItemsVertically();
	but_2->setAnchorPoint(Point(0, 0));
	but_2->setPosition(Point(1200, 450));
	but_2->setTag(BUT_2);
	this->addChild(but_2);

}
void UserLayer::button(Ref *sender) {
	auto buttag = (MenuItem*)sender;

	if (!dataSingleton::getInstance()->winopen) {
	
		if (buttag->getTag() == statb) {
			auto statusLayer = statuswinLayer::create();
			this->addChild(statusLayer);
		}
		else if (buttag->getTag() == itemb) {
			auto itemLayer = itemwinLayer::create();
			this->addChild(itemLayer);
		}
		else if (buttag->getTag() == skillb) {
		}
		else if (buttag->getTag() == questb) {
		}
		else if (buttag->getTag() == exitb) {
			//�����ϰڴٴ� ��Ʈ Y/N ���� �� json ��� ���� �� ����
		}
		/*	else if (buttag->getTag() == backb) {
		//�����¾����� ���ư��ڳĴ� ���� ����
		Director::getInstance()->replaceScene(ElyonScene::createScene());
		}*/
	}
}



void UserLayer::levelupeffect() {
	auto px = dataSingleton::getInstance()->x;
	auto py = dataSingleton::getInstance()->y;
	auto levelupPa = ParticleSystemQuad::create("levelup.plist");
	levelupPa->setDuration(0.5);
	levelupPa->setScale(0.7);
	levelupPa->setPosition(Point(px, py));
	this->addChild(levelupPa);

	auto leveluplabel = Label::createWithTTF("LEVEL UP", "drfont.ttf", 40);
	leveluplabel->setPosition(Point(px, py + 300));
	leveluplabel->enableGlow(Color4B::YELLOW);
	leveluplabel->setColor(Color3B(255, 255, 198));
	this->addChild(leveluplabel);

	auto fade = FadeOut::create(1.0f);
	auto move = MoveBy::create(2, Point(0, 50));
	auto spaw = Spawn::create(fade, move, NULL);
	auto dt = DelayTime::create(1.0);
	auto seq = Sequence::create(dt, spaw, NULL);
	leveluplabel->runAction(seq);

}

void UserLayer::shiftpush(Ref* sender) {
	auto background = (Sprite*)this->getChildByTag(BACK);
	background->setOpacity(50);

	auto magic1 = (Sprite*)this->getChildByTag(MAGIC1);
	magic1->setOpacity(50);

	auto magic2 = (Sprite*)this->getChildByTag(MAGIC2);
	magic2->setOpacity(50);

	auto risenwin = (Sprite*)this->getChildByTag(RISE_WIN);
	risenwin->setOpacity(50);

	auto but_1 = (Menu*)this->getChildByTag(BUT_1);
	but_1->setOpacity(50);

	auto but_2 = (Menu*)this->getChildByTag(BUT_2);
	but_2->setOpacity(50);

	auto msg = Sprite::create("message2.png");
	msg->setScale(0.7);
	msg->setPosition(Point(Director::getInstance()->
		getWinSize().width / 2, Director::getInstance()->
		getWinSize().height / 2 + 100));
	msg->setTag(MSG);
	this->addChild(msg);

	auto cancel = MenuItemImage::create("cancel.png", "cancel_push.png", CC_CALLBACK_1(UserLayer::shiftokay, this));
	cancel->setTag(CA);
	auto cc = Menu::create(cancel, NULL);
	cc->alignItemsVertically();
	cc->setAnchorPoint(Point(0, 0));
	cc->setTag(CA1);
	cc->setPosition(Point(Director::getInstance()->
		getWinSize().width / 2 + 225, Director::getInstance()->
		getWinSize().height / 2 - 100));
	this->addChild(cc);

	auto okay = MenuItemImage::create("check.png", "check_push.png", CC_CALLBACK_1(UserLayer::shiftokay, this));
	okay->setTag(OK);
	auto oa = Menu::create(okay, NULL);
	oa->alignItemsVertically();
	oa->setAnchorPoint(Point(0, 0));
	oa->setTag(OK1);
	oa->setPosition(Point(Director::getInstance()->
		getWinSize().width / 2 - 225, Director::getInstance()->
		getWinSize().height / 2 - 100));
	this->addChild(oa);


}
// ��ų Ÿ�̸� �Լ�
void UserLayer::addLabelTimer(cocos2d::Node* pParent, int nTime, const cocos2d::Vec2& pos)
{
	auto pLabelTime = Label::create(StringUtils::toString(nTime), "Arial", 40);
	pLabelTime->setUserData((int*)nTime);
	pParent->addChild(pLabelTime);
	pLabelTime->setPosition(pos);

	auto scheduleAction = CallFuncN::create(CC_CALLBACK_0(UserLayer::updateLabel, this, pLabelTime));
	auto repeatF = RepeatForever::create(Sequence::create(scheduleAction, DelayTime::create(1.0f), nullptr));
	pLabelTime->runAction(repeatF);

}

void UserLayer::updateLabel(cocos2d::Label* pLabel)
{
	if (pLabel)
	{
		int userTime = (int)(pLabel->getUserData());
		userTime -= 1;
		pLabel->setString(StringUtils::toString(userTime));


		if (userTime <= 0)
		{
			//�� ��������, �ð��� 0�� �Ǿ������� ���۳����� �����մϴ�.

			pLabel->stopAllActions();
			skillbox1->removeChild(pLabel,1);
			skilltime = false;
			dataSingleton::getInstance()->skillpressedA = false;
			

			return;
		}


		pLabel->setUserData((int*)userTime);
	}
}
void UserLayer::risenpush(Ref* sender) {

	auto background = (Sprite*)this->getChildByTag(BACK);
	background->setOpacity(50);

	auto magic1 = (Sprite*)this->getChildByTag(MAGIC1);
	magic1->setOpacity(50);

	auto magic2 = (Sprite*)this->getChildByTag(MAGIC2);
	magic2->setOpacity(50);

	auto risenwin = (Sprite*)this->getChildByTag(RISE_WIN);
	risenwin->setOpacity(50);

	auto but_1 = (Menu*)this->getChildByTag(BUT_1);
	but_1->setOpacity(50);

	auto but_2 = (Menu*)this->getChildByTag(BUT_2);
	but_2->setOpacity(50);

	auto msg = Sprite::create("message.png");
	msg->setScale(0.7);
	msg->setPosition(Point(Director::getInstance()->
		getWinSize().width / 2, Director::getInstance()->
		getWinSize().height / 2 + 100));
	msg->setTag(MSG);
	this->addChild(msg);

	auto cancel = MenuItemImage::create("cancel.png", "cancel_push.png", CC_CALLBACK_1(UserLayer::risenokay, this));
	cancel->setTag(CA);
	auto cc = Menu::create(cancel, NULL);
	cc->alignItemsVertically();
	cc->setAnchorPoint(Point(0, 0));
	cc->setTag(CA1);
	cc->setPosition(Point(Director::getInstance()->
		getWinSize().width / 2 +225, Director::getInstance()->
		getWinSize().height / 2 - 100));
	this->addChild(cc);

	auto okay = MenuItemImage::create("check.png", "check_push.png", CC_CALLBACK_1(UserLayer::risenokay, this));
	okay->setTag(OK);
	auto oa = Menu::create(okay, NULL);
	oa->alignItemsVertically();
	oa->setAnchorPoint(Point(0, 0));
	oa->setTag(OK1);
	oa->setPosition(Point(Director::getInstance()->
		getWinSize().width / 2 - 225, Director::getInstance()->
		getWinSize().height / 2 - 100));
	this->addChild(oa);


}
void UserLayer::shiftokay(Ref* sender) {
	auto q = (MenuItem*)sender;
	switch (q->getTag()) {

	case OK: {  


			auto background = (Sprite*)this->getChildByTag(BACK);
			this->removeChild(background);

			auto magic1 = (Sprite*)this->getChildByTag(MAGIC1);
			this->removeChild(magic1);

			auto magic2 = (Sprite*)this->getChildByTag(MAGIC2);
			this->removeChild(magic2);

			auto risenwin = (Sprite*)this->getChildByTag(RISE_WIN);
			this->removeChild(risenwin);


			auto but_1 = (Menu*)this->getChildByTag(BUT_1);
			this->removeChild(but_1);

			auto but_2 = (Menu*)this->getChildByTag(BUT_2);
			this->removeChild(but_2);

			auto msg = (Sprite*)this->getChildByTag(MSG);
			this->removeChild(msg);

			auto oa = (Menu*)this->getChildByTag(OK1);
			this->removeChild(oa);

			auto cc = (Menu*)this->getChildByTag(CA1);
			this->removeChild(cc);

			dataSingleton::getInstance()->playerDead = false;
			gameovertrue = false;
			auto maxhp = pL->jjgetInt("maxhp", "test");
			auto maxmp = pL->jjgetInt("maxmp", "test");
			auto penlhp = maxhp*0.1;
			auto penlmp = maxmp*0.1;
			pL->jjsetInt(penlhp, "hp", "test");
			pL->jjsetInt(penlmp, "mp", "test");
			Director::getInstance()->replaceScene(ElyonScene::createScene());

			break;
		}
	case CA: {

		auto background = (Sprite*)this->getChildByTag(BACK);
		background->setOpacity(255);

		auto magic1 = (Sprite*)this->getChildByTag(MAGIC1);
		magic1->setOpacity(255);

		auto magic2 = (Sprite*)this->getChildByTag(MAGIC2);
		magic2->setOpacity(255);

		auto risenwin = (Sprite*)this->getChildByTag(RISE_WIN);
		risenwin->setOpacity(255);

		auto but_1 = (Menu*)this->getChildByTag(BUT_1);
		but_1->setOpacity(255);

		auto but_2 = (Menu*)this->getChildByTag(BUT_2);
		but_2->setOpacity(255);

		auto msg = (Sprite*)this->getChildByTag(MSG);
		this->removeChild(msg);

		auto oa = (Menu*)this->getChildByTag(OK1);
		this->removeChild(oa);

		auto cc = (Menu*)this->getChildByTag(CA1);
		this->removeChild(cc);

		break;
	}
	default: {
		break;
	}
	}


}
void UserLayer::risenokay(Ref* sender) {
	auto q = (MenuItem*)sender;
	switch (q->getTag()) {

	case OK: {  //�� ���� ��Ȱ�ϴ� �� ����,   ��Ȱ�ϴ� �������׸��� ��Ȱ�ϱ� �����̵� �� �ڿ� �̹����� �� ����


		int havemoney = pL->jjgetInt("money", "test");
		if (havemoney >= 3000)
		{
			auto background = (Sprite*)this->getChildByTag(BACK);
			this->removeChild(background);

			auto magic1 = (Sprite*)this->getChildByTag(MAGIC1);
			this->removeChild(magic1);

			auto magic2 = (Sprite*)this->getChildByTag(MAGIC2);
			this->removeChild(magic2);

			auto risenwin = (Sprite*)this->getChildByTag(RISE_WIN);
			this->removeChild(risenwin);


			auto but_1 = (Menu*)this->getChildByTag(BUT_1);
			this->removeChild(but_1);

			auto but_2 = (Menu*)this->getChildByTag(BUT_2);
			this->removeChild(but_2);

			auto msg = (Sprite*)this->getChildByTag(MSG);
			this->removeChild(msg);

			auto oa = (Menu*)this->getChildByTag(OK1);
			this->removeChild(oa);

			auto cc = (Menu*)this->getChildByTag(CA1);
			this->removeChild(cc);

			havemoney = havemoney - 3000;
			pL->jjsetInt(havemoney, "money", "test");

			PHP = pL->jjgetInt("maxhp", "test");
			dataSingleton::getInstance()->pHP = PHP;
			pL->jjsetInt(PHP, "hp", "test");

			PMP = pL->jjgetInt("maxmp", "test");
			dataSingleton::getInstance()->pMP = PMP;
			pL->jjsetInt(PMP, "mp", "test");

			dataSingleton::getInstance()->risen = true;
			dataSingleton::getInstance()->playerDead = false;
			gameovertrue = false;
		}
		else if (havemoney < 3000)
		{
			auto lack = LabelTTF::create("���� �ݾ��� �����մϴ�", "Thonburi", 30);
			lack->setPosition(Point(1000, 900));
			auto act1 = DelayTime::create(2.0);
			auto act2 = FadeOut::create(1.5);
			auto act3 = Sequence::create(act1, act2, NULL);
			lack->runAction(act3);
			this->addChild(lack);
		}


		break;
	}
	case CA: {

		auto background = (Sprite*)this->getChildByTag(BACK);
		background->setOpacity(255);

		auto magic1 = (Sprite*)this->getChildByTag(MAGIC1);
		magic1->setOpacity(255);

		auto magic2 = (Sprite*)this->getChildByTag(MAGIC2);
		magic2->setOpacity(255);

		auto risenwin = (Sprite*)this->getChildByTag(RISE_WIN);
		risenwin->setOpacity(255);

		auto but_1 = (Menu*)this->getChildByTag(BUT_1);
		but_1->setOpacity(255);

		auto but_2 = (Menu*)this->getChildByTag(BUT_2);
		but_2->setOpacity(255);

		auto msg = (Sprite*)this->getChildByTag(MSG);
		this->removeChild(msg);

		auto oa = (Menu*)this->getChildByTag(OK1);
		this->removeChild(oa);

		auto cc = (Menu*)this->getChildByTag(CA1);
		this->removeChild(cc);

		break;
	}
	default: {
		break;
	}
	}

}