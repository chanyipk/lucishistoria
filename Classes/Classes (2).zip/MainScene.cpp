#include "MainScene.h"
#include "CharacterScene.h"
#include "NoticeLayer.h"
#include "EventLayer.h"
#include "MainLayer.h"
#include "MapScene.h"
#include "dataSingleton.h"
#include "../../cocos2d/external/json/rapidjson.h"
#include "../../cocos2d/external/json/document.h"
#include "../../cocos2d/external/json/filestream.h"
#include "Jdata.h"

using namespace rapidjson;

Jdata* mainpL;

Scene* MainScene::createScene()
{
	// 'scene' is an autorelease object
	auto scene = Scene::create();

	// 'layer' is an autorelease object
	auto layer = MainScene::create();

	// add layer as a child to scene
	scene->addChild(layer);

	// return the scene
	return scene;
}

// on "init" you need to initialize your instance
bool MainScene::init()
{
	//////////////////////////////
	// 1. super init first

	if (!Layer::init())
	{
		return false;
	}

	dataSingleton::getInstance()->isUser = true;
	initBG();

	//���� �� 4���� ������ â
	auto winback_1 = Sprite::create("winback.png");
	winback_1->setAnchorPoint(Point(0, 1));
	winback_1->setPosition(Point(1100, 1050));
	this->addChild(winback_1);

	auto winback_2 = Sprite::create("winback.png");
	winback_2->setAnchorPoint(Point(0, 1));
	winback_2->setPosition(Point(1100, 783));
	this->addChild(winback_2);

	auto winback_3 = Sprite::create("winback.png");
	winback_3->setAnchorPoint(Point(0, 1));
	winback_3->setPosition(Point(1100, 516));
	this->addChild(winback_3);

	auto winback_4 = Sprite::create("winback.png");
	winback_4->setAnchorPoint(Point(0, 1));
	winback_4->setPosition(Point(1100, 249));
	this->addChild(winback_4);

	dataSingleton::getInstance()->touch = true;//���۹�ư ������ư Ŭ���ȵǰ�
	dataSingleton::getInstance()->enable = true;//���� �̺�Ʈ ��ø����

												//   ���� �ϴ� ĳ���� ���� �� ���� ��ư
	auto charmake = MenuItemImage::create("create.png", "create_push.png", CC_CALLBACK_1(MainScene::changeScene, this));
	auto chardelete = MenuItemImage::create("delete.png", "delete_push.png", CC_CALLBACK_1(MainScene::changeScene, this));

	auto crebut = Menu::create(charmake, NULL);
	crebut->setAnchorPoint(Point(0, 0));
	crebut->setPosition(Point(200, 100));
	crebut->setScale(0.6);
	this->addChild(crebut);

	auto delbut = Menu::create(chardelete, NULL);
	delbut->setAnchorPoint(Point(0, 0));
	delbut->setPosition(Point(500, 100));
	delbut->setScale(0.6);
	this->addChild(delbut);


	//���� ��� 2�� ��ư �ϳ��� ����, �ٸ� �ϳ��� �̺�Ʈ ��ư -> ���ο� ���� ����� �ش� ��ư Ŭ�� �� �ش� ������ �̵��ϴ� ������ 
	auto cirbut_1 = MenuItemImage::create("cirbut.png", "cirbut_push.png", CC_CALLBACK_1(MainScene::ButtonCallBack1, this));
	auto cirbut_2 = MenuItemImage::create("cirbut.png", "cirbut_push.png", CC_CALLBACK_1(MainScene::ButtonCallBack2, this));

	cirbut_1->setTag(CIRBUT_1);
	cirbut_2->setTag(CIRBUT_2);
	auto but_1 = Menu::create(cirbut_1, NULL);
	but_1->alignItemsVertically();
	but_1->setAnchorPoint(Point(0, 0));
	but_1->setPosition(Point(150, 900));
	but_1->setScale(0.6);
	this->addChild(but_1);

	auto but_2 = Menu::create(cirbut_2, NULL);
	but_2->alignItemsVertically();
	but_2->setAnchorPoint(Point(0, 0));
	but_2->setPosition(Point(150, 700));
	but_2->setScale(0.6);
	this->addChild(but_2);


	log("isUser: %d", dataSingleton::getInstance()->isUser);
	log("mainPL: %d", mainpL->fileRead("test"));
	//0215�߰�
	mainpL->jjnamelist();
	if (dataSingleton::getInstance()->isUser == true || mainpL->fileRead("test") == true) {
		plyrListshow();
	}

	auto e = MenuItemImage::create("enter.png", "enter_push.png", CC_CALLBACK_1(MainScene::gotomapScene, this));
	e->setScale(0.6);
	auto ebtn = Menu::create(e, NULL);
	ebtn->setAnchorPoint(Point::ZERO);
	ebtn->setPosition(800, 100);
	ebtn->setTag(ENTERBTN);
	ebtn->setVisible(false);
	this->addChild(ebtn);


	//������ 4���� ������ �簢���ڸ� �ѷ��װ� �ִ� �ݻ� �׵θ�
	auto side = Sprite::create("side.png");
	side->setAnchorPoint(Point(0, 1));
	side->setPosition(Point(1100, 1050));
	this->addChild(side);

	return true;
}

void MainScene::plyrListshow() {

	//0206 �߰� �ڵ�
	std::string userPath = "C:\\json\\";
	userPath.append("name.json");

	bool isF = FileUtils::sharedFileUtils()->isFileExist(userPath);
	if (isF) {
		std::string userdocdata;
		userdocdata.clear();
		userdocdata = FileUtils::getInstance()->getStringFromFile(userPath);

		Document udoc;

		if (!udoc.Parse<0>(userdocdata.c_str()).HasParseError()) {
			log("failed Parsing from userdocdata");
		}

		const rapidjson::Value& docP = udoc["name"];
		int level = mainpL->jjgetInt("level", "test");


		std::string user0 = docP[0].GetString();  //�̸�
		std::string user1 = std::to_string(level);  //����

		std::string user2 = "LV. " + user1 + "  " + user0;

		auto player_but = MenuItemImage::create("selectwin.png", "selectwin_push.png", CC_CALLBACK_1(MainScene::playerSelect, this));
		player_but->setTag(PLAYER_0);
		auto plyr = Menu::create(player_but, NULL);
		plyr->setPosition(Point(1505, 915));
		this->addChild(plyr);

		auto player0 = Label::createWithTTF(user2, "nanumgo.ttf", 40);
		player0->setColor(Color3B(255, 223, 36));
		player0->setPosition(1300, 950);
		this->addChild(player0);

	}
	else {
		mainpL->jjnamelist();
	}
}


void MainScene::gotomapScene(Ref *sender)
{
	if (dataSingleton::getInstance()->touch) {

		Director::getInstance()->replaceScene(MapScene::createScene());
	}
}
void MainScene::playerSelect(Ref* sender) {

	auto playerbtn = (MenuItem*)sender;
	cocos2d::Menu *etbtn;
	etbtn = (Menu*)this->getChildByTag(ENTERBTN);
	etbtn->setVisible(true);

	/*
	switch (playerbtn->getTag()) {
	case PLAYER_0:
	{
	//dataSingleton::getInstance()->usertag = 0;
	log("playerbtn: %d", dataSingleton::getInstance()->usertag);
	break;
	}
	case PLAYER_1:
	{
	//dataSingleton::getInstance()->usertag = 1;
	//log("playerbtn: %d", dataSingleton::getInstance()->usertag);
	break;
	}
	default: {
	break;
	}
	}*/
}

void MainScene::initBG()
{
	auto spr = Sprite::create("back.png");
	spr->setPosition(Point(Director::getInstance()->
		getWinSize().width / 2, Director::getInstance()->
		getWinSize().height / 2));
	this->addChild(spr);


}

void MainScene::ButtonCallBack1(cocos2d::Ref *sender)
{
	if (dataSingleton::getInstance()->enable)
	{
		dataSingleton::getInstance()->enable = false;

		auto noticelayer = NoticeLayer::create();
		this->addChild(noticelayer);
	}

}

void MainScene::ButtonCallBack2(cocos2d::Ref *sender)
{
	if (dataSingleton::getInstance()->enable)
	{
		dataSingleton::getInstance()->enable = false;
		auto eventlayer = EventLayer::create();
		this->addChild(eventlayer);
	}
}



void MainScene::changeScene(Ref *sender)
{
	if (dataSingleton::getInstance()->touch) {

		Director::getInstance()->replaceScene(CharacterScene::createScene());
	}
}



void MainScene::ButtonCallBack3(cocos2d::Ref *sender)
{
	auto mainlayer = MainLayer::create();
	this->addChild(mainlayer);
}